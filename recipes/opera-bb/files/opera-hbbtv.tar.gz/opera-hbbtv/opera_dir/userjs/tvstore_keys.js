<!-- This is an opera userjs for the creation of visual objects  -->

<!-- keypress event keyCode mapping of keys used in Opera TV Store -->

var VK_UNSUPPORTED = null;
var VK_BACK_SPACE = 8;
var VK_ENTER = 13;
var VK_PAUSE = 10;
var VK_LEFT = 37;
var VK_UP = 38;
var VK_RIGHT = 39;
var VK_DOWN = 40;
var VK_0 = 48;
var VK_1 = 49;
var VK_2 = 50;
var VK_3 = 51;
var VK_4 = 52;
var VK_5 = 53;
var VK_6 = 54;
var VK_7 = 55;
var VK_8 = 56;
var VK_9 = 57;
<!-- Color keys F1 - F4 -->
var VK_RED = 61506; 
var VK_GREEN = 61507;
var VK_YELLOW = 61506;
var VK_BLUE = 61509;

var VK_REWIND = VK_UNSUPPORTED;
var VK_STOP = VK_UNSUPPORTED;
var VK_PLAY = VK_UNSUPPORTED;
var VK_RECORD = VK_UNSUPPORTED;
var VK_FAST_FWD = VK_UNSUPPORTED;
var VK_TRACK_PREV = VK_UNSUPPORTED;
var VK_TRACK_NEXT = VK_UNSUPPORTED;
var VK_CHANNEL_UP = VK_UNSUPPORTED;
var VK_CHANNEL_DOWN = VK_UNSUPPORTED;
var VK_VOLUME_UP = VK_UNSUPPORTED;
var VK_VOLUME_DOWN = VK_UNSUPPORTED;
var VK_MUTE = VK_UNSUPPORTED;
var VK_INFO = VK_UNSUPPORTED;
var VK_SUBTITLE = VK_UNSUPPORTED;
var VK_MENU = VK_UNSUPPORTED;

