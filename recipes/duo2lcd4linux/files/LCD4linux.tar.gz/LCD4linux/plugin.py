#
# LCD4linux - Pearl DPF LCD Display
#
# written by joergm6 @ IHAD
#
Version = "V0.8r3"
from __init__ import _

from enigma import eConsoleAppContainer, eActionMap, iServiceInformation, iFrontendInformation
from enigma import getDesktop 
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Language import language
from Screens.MessageBox import MessageBox
# imports
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
import xml.dom.minidom
import urllib
#import sys
import os
import textwrap
import codecs
import StringIO
import ctypes.util
#import pickle
import glob

import string
from time import gmtime, strftime, localtime, mktime, time, sleep
from datetime import datetime

from Components.ServiceEventTracker import ServiceEventTracker
from enigma import eTimer, eEPGCache, loadPNG, eListboxPythonMultiContent, gFont, eServiceReference, eServiceCenter, iPlayableService
from RecordTimer import RecordTimer, RecordTimerEntry, parseEvent
from Screens import Standby 

from Components.config import configfile, getConfigListEntry, ConfigEnableDisable, \
	ConfigYesNo, ConfigText, ConfigClock, ConfigNumber, ConfigSelectionNumber, ConfigSelection, \
	config, ConfigSubsection, ConfigSubList, ConfigSubDict, ConfigIP, ConfigSlider, ConfigDirectory
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText

from twisted.web.client import getPage
from xml.dom.minidom import parse, parseString
from urllib import urlencode
import xml.etree.cElementTree

import png_util

pngutil = png_util.PNGUtil()

# globals
DPFrefreshrate="/usr/lib/enigma2/python/Plugins/Extensions/LCD4linux/refreshrate"
WetterPath = "/usr/lib/enigma2/python/Plugins/Extensions/LCD4linux/wetter/"
FONT="/usr/share/fonts/nmsbd.ttf"
PIC="/tmp/dpf"
PICtmp="/tmp/dpftmp"
PIC2="/tmp/dpf2"
PIC2tmp="/tmp/dpf2tmp"
PICwetter="/tmp/dpfwetter.png"
HTTPpic="/tmp/dpfhttp.png"
HTTPpictmp="/tmp/dpfhttptmp.png"
PICbright="/tmp/dpflight"
TXTdemo="/tmp/lcd4linux.demo"
LCDon = True
ConfigMode = False
ConfigStandby = False
OSDon = 0
OSDtimer = -5
OSDdontshow = ["Virtual Zap","InfoBar","LCD4linux Settings","FanControl2","Mute","LCD Text","UnhandledKey","QuickZap","Volume","PVRState"]
OSDdontskin = ["VirtualZap","InfoBarSummary","PictureInPicture","SimpleSummary","TimeshiftState","InfoScreen","Standby"]
wwwWetter = ""
WetterType = ""
ScreenActive = "1"
ScreenTime= 0
isVideoPlaying = 0
Bilder = []
BilderStandby = []
BilderIndex = 0
BilderIndexStandby = 0
BilderTime = 0
ThreadRunning = 0
LastDemon = ""
DemonPID = ["","","",""]
SamsungDevice = None
SamsungDevice2 = None
isMediaPlayer = ""

USBok = False
if ctypes.util.find_library("usb-1.0") is not None and ctypes.util.find_library("usb-0.1") is not None:
	print "[LCD4linux] libusb found :-)"
	import Photoframe
	USBok = True

Farbe = [("black", _("black")), ("white", _("white")), 
 ("gray", _("gray")), ("silver", _("silver")), ("slategray", _("slategray")),
 ("aquamarine", _("aquamarine")),
 ("yellow", _("yellow")), ("greenyellow", _("greenyellow")),
 ("red", _("red")), ("orange", _("orange")), ("darkorange", _("darkorange")), ("orangered", _("orangered")),
 ("green", _("green")), ("lightgreen", _("lightgreen")), ("blue", _("blue")), ("lightblue", _("lightblue")),
 ("magenta", _("magenta")), ("violet", _("violet")), ("cyan", _("cyan")),
 ("brown", _("brown")), ("sandybrown", _("sandybrown")), ("rosybrown", _("rosybrown")), ("olive", _("olive")),
]
ScreenSelect = [("0", _("off")), ("1", _("Screen 1")), ("2", _("Screen 2")), ("3", _("Screen 3")), ("12", _("Screen 1+2")), ("13", _("Screen 1+3")), ("23", _("Screen 2+3")), ("123", _("Screen 1+2+3")), ("4", _("Screen 4")), ("14", _("Screen 1+4")), ("24", _("Screen 2+4")), ("34", _("Screen 3+4")), ("124", _("Screen 1+2+4")), ("134", _("Screen 1+3+4")), ("234", _("Screen 2+3+4")), ("1234", _("Screen 1+2+3+4"))]
TimeSelect = [("1", _("5s")), ("2", _("10s")), ("3", _("15s")), ("4", _("20s")), ("6", _("30s")), ("12", _("1min")), ("24", _("2min"), ("60", _("5min")))]
LCDSelect = [("1", _("LCD 1")), ("2", _("LCD 2")), ("12", _("LCD 1+2"))]
LCDType = [("10", _("Vu LCD 400x240"))]

config.plugins.LCD4linux = ConfigSubsection()
config.plugins.LCD4linux.Enable = ConfigYesNo(default = False)
config.plugins.LCD4linux.Thread = ConfigYesNo(default = False)
config.plugins.LCD4linux.ScreenActive = ConfigSelection(choices = [("1", _("Screen 1")), ("2", _("Screen 2")), ("3", _("Screen 3")), ("4", _("Screen 4"))], default="1")
config.plugins.LCD4linux.ScreenMax = ConfigSelection(choices = [("1", _("Screen 1")), ("2", _("Screen 1-2")), ("3", _("Screen 1-3")), ("4", _("Screen 1-4"))], default="1")
config.plugins.LCD4linux.ScreenTime = ConfigSelection(choices = [("0", _("off"))] + TimeSelect, default="0")
config.plugins.LCD4linux.ScreenTime2 = ConfigSelection(choices = TimeSelect, default="1")
config.plugins.LCD4linux.ScreenTime3 = ConfigSelection(choices = TimeSelect, default="1")
config.plugins.LCD4linux.ScreenTime4 = ConfigSelection(choices = TimeSelect, default="1")
config.plugins.LCD4linux.BilderTime = ConfigSelection(choices =  [("0", _("off"))] + TimeSelect, default="0")
config.plugins.LCD4linux.Helligkeit = ConfigSlider(default = 5,  limits = (0, 7))
config.plugins.LCD4linux.LCDoff = ConfigClock(default = ((5 * 60 + 0) * 60) )
config.plugins.LCD4linux.LCDon = ConfigClock(default = ((5 * 60 + 0) * 60) )
config.plugins.LCD4linux.Refresh = ConfigSlider(default = 3,  limits = (1, 15))
config.plugins.LCD4linux.Delay = ConfigSlider(default = 200,  increment = 50, limits = (50, 2000))
config.plugins.LCD4linux.WetterCity = ConfigText(default="Berlin", fixed_size=False)
config.plugins.LCD4linux.LCDType1 = ConfigSelection(choices = LCDType, default="10")
config.plugins.LCD4linux.LCDType2 = ConfigSelection(choices = [("00", _("off"))] + LCDType, default="00")
config.plugins.LCD4linux.LCDRotate1 = ConfigSelection(choices = [("0", _("0")), ("90", _("90")), ("180", _("180"))], default="0")
config.plugins.LCD4linux.LCDRotate2 = ConfigSelection(choices = [("0", _("0")), ("90", _("90")), ("180", _("180"))], default="0")
config.plugins.LCD4linux.DemonCheck = ConfigYesNo(default = False)
config.plugins.LCD4linux.OSD = ConfigSelection(choices =  [("0", _("disabled"))] + TimeSelect, default="0")
config.plugins.LCD4linux.OSDLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.OSDsize = ConfigSlider(default = 425,  increment = 5, limits = (320, 1024))
config.plugins.LCD4linux.OSDfast = ConfigYesNo(default = False)
config.plugins.LCD4linux.KeySwitch = ConfigYesNo(default = True)
config.plugins.LCD4linux.Recording = ConfigYesNo(default = True)
config.plugins.LCD4linux.Picon = ConfigSelection(choices = ScreenSelect, default="1")
config.plugins.LCD4linux.PiconLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.PiconType = ConfigSelection(choices = [("1", _("full")), ("2", _("half-above")), ("3", _("half-below"))], default="1")
config.plugins.LCD4linux.PiconSize = ConfigSlider(default = 240,  increment = 10, limits = (10, 800))
config.plugins.LCD4linux.PiconPath = ConfigText(default="/usr/share/enigma2/picon/", fixed_size=False)
config.plugins.LCD4linux.PiconPathAlt = ConfigText(default="", fixed_size=False)
config.plugins.LCD4linux.PiconCache = ConfigText(default="/usr/share/enigma2/piconcache/", fixed_size=False)
config.plugins.LCD4linux.PiconAspectRatio = ConfigSelection(choices = [("0", _("off")), ("1", _("on"))], default="0")
config.plugins.LCD4linux.PiconAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.PiconTextSize = ConfigSlider(default = 30,  increment = 2, limits = (10, 150))
config.plugins.LCD4linux.Clock = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.ClockLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.ClockType = ConfigSelection(choices = [("1", _("Time")), ("2", _("Date+Time")), ("3", _("Date"))], default="1")
config.plugins.LCD4linux.ClockSize = ConfigSlider(default = 70,  increment = 2, limits = (10, 150))
config.plugins.LCD4linux.ClockPos = ConfigSlider(default = 150,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.ClockAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.ClockSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.ClockColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Channel = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.ChannelLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.ChannelSize = ConfigSlider(default = 50,  increment = 2, limits = (10, 150))
config.plugins.LCD4linux.ChannelPos = ConfigSlider(default = 10,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.ChannelColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.ChannelNum = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.ChannelNumLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.ChannelNumSize = ConfigSlider(default = 60,  increment = 2, limits = (10, 200))
config.plugins.LCD4linux.ChannelNumPos = ConfigSlider(default = 10,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.ChannelNumAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="0")
config.plugins.LCD4linux.ChannelNumColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.ChannelNumBackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="black")
config.plugins.LCD4linux.Prog = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.ProgLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.ProgType = ConfigSelection(choices = [("1", _("Time+Info")), ("2", _("Info"))], default="1")
config.plugins.LCD4linux.ProgSize = ConfigSlider(default = 32,  increment = 1, limits = (10, 150))
config.plugins.LCD4linux.ProgLines = ConfigSelectionNumber(1, 5, 1, default = 3)
config.plugins.LCD4linux.ProgPos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.ProgAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.ProgSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.ProgColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.ProgNext = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.ProgNextLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.ProgNextType = ConfigSelection(choices = [("1", _("Time+Info")), ("2", _("Info"))], default="1")
config.plugins.LCD4linux.ProgNextSize = ConfigSlider(default = 32,  increment = 1, limits = (10, 150))
config.plugins.LCD4linux.ProgNextLines = ConfigSelectionNumber(1, 5, 1, default = 3)
config.plugins.LCD4linux.ProgNextPos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.ProgNextAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.ProgNextSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.ProgNextColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Progress = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.ProgressLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.ProgressType = ConfigSelection(choices = [("1", _("only Progress Bar")), ("2", _("with Remaining Minutes")), ("3", _("with Percent"))], default="1")
config.plugins.LCD4linux.ProgressSize = ConfigSlider(default = 10,  increment = 1, limits = (5, 100))
config.plugins.LCD4linux.ProgressAlign = ConfigSelection(choices = [("0", _("half left")), ("1", _("center")), ("2", _("half right"))], default="1")
config.plugins.LCD4linux.ProgressPos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.ProgressColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Info = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.InfoLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.InfoTuner = ConfigSelection(choices = [("", _("no")), ("A", _("db")), ("B", _("%")), ("AB", _("db + %")), ("ABC", _("db + % + BER")), ("AC", _("db + BER")), ("BC", _("% + BER"))], default="")
config.plugins.LCD4linux.InfoSensor = ConfigSelection(choices = [("", _("no")), ("R", _("rpm")), ("T", _("C")), ("RT", _("rmp + C"))], default="")
config.plugins.LCD4linux.InfoSize = ConfigSlider(default = 20,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.InfoPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.InfoAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.InfoSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.InfoColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Timer = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.TimerLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.TimerSize = ConfigSlider(default = 22,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.TimerPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.TimerColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Wetter = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.WetterLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.WetterPos = ConfigSlider(default = 50,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.WetterType = ConfigSelection(choices = [("1", _("4 Days small")), ("2", _("4 Days big")), ("3", _("Current big")), ("4", _("Current full"))], default="1")
config.plugins.LCD4linux.WetterCity = ConfigText(default="Berlin", fixed_size=False)
config.plugins.LCD4linux.Text = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.TextLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.TextFile = ConfigText(default="/tmp/lcd4linux.txt", fixed_size=False)
config.plugins.LCD4linux.TextSize = ConfigSlider(default = 32,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.TextPos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.TextAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="0")
config.plugins.LCD4linux.TextColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.TextBackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="0")
config.plugins.LCD4linux.Text2 = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.Text2LCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.Text2File = ConfigText(default="/tmp/lcd4linux.txt", fixed_size=False)
config.plugins.LCD4linux.Text2Size = ConfigSlider(default = 32,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.Text2Pos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.Text2Align = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="0")
config.plugins.LCD4linux.Text2Color = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Text2BackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="0")
config.plugins.LCD4linux.HTTP = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.HTTPLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.HTTPURL = ConfigText(default="http://", fixed_size=False)
config.plugins.LCD4linux.HTTPSize = ConfigSlider(default = 20,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.HTTPPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.HTTPAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="0")
config.plugins.LCD4linux.HTTPColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.HTTPBackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="0")
config.plugins.LCD4linux.Bild = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.BildLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.BildFile = ConfigText(default="/tmp/lcd4linux.jpg", fixed_size=False)
config.plugins.LCD4linux.BildSize = ConfigSlider(default = 240,  increment = 10, limits = (10, 800))
config.plugins.LCD4linux.BildPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.BildAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center"))], default="0")
config.plugins.LCD4linux.MPScreenMax = ConfigSelection(choices = [("1", _("Screen 1")), ("2", _("Screen 1-2")), ("3", _("Screen 1-3"))], default="1")
config.plugins.LCD4linux.MPTitle = ConfigSelection(choices = ScreenSelect, default="1")
config.plugins.LCD4linux.MPTitleLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.MPTitleSize = ConfigSlider(default = 32,  increment = 1, limits = (10, 150))
config.plugins.LCD4linux.MPTitleLines = ConfigSelectionNumber(1, 5, 1, default = 3)
config.plugins.LCD4linux.MPTitlePos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.MPTitleAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.MPTitleSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.MPTitleColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.MPInfo1 = ConfigSelection(choices = ScreenSelect, default="1")
config.plugins.LCD4linux.MPInfo1LCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.MPInfo1Size = ConfigSlider(default = 32,  increment = 1, limits = (10, 150))
config.plugins.LCD4linux.MPInfo1Lines = ConfigSelectionNumber(1, 5, 1, default = 3)
config.plugins.LCD4linux.MPInfo1Pos = ConfigSlider(default = 130,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.MPInfo1Align = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.MPInfo1Split = ConfigYesNo(default = False)
config.plugins.LCD4linux.MPInfo1Color = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.MPProgress = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.MPProgressLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.MPProgressType = ConfigSelection(choices = [("1", _("only Progress Bar")), ("2", _("with Remaining Minutes")), ("3", _("with Percent"))], default="1")
config.plugins.LCD4linux.MPProgressSize = ConfigSlider(default = 10,  increment = 1, limits = (5, 100))
config.plugins.LCD4linux.MPProgressPos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.MPProgressAlign = ConfigSelection(choices = [("0", _("half left")), ("1", _("center")), ("2", _("half right"))], default="1")
config.plugins.LCD4linux.MPProgressColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.MPClock = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.MPClockLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.MPClockType = ConfigSelection(choices = [("1", _("Time")), ("2", _("Date+Time")), ("3", _("Date"))], default="1")
config.plugins.LCD4linux.MPClockSize = ConfigSlider(default = 70,  increment = 2, limits = (10, 150))
config.plugins.LCD4linux.MPClockPos = ConfigSlider(default = 150,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.MPClockAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.MPClockSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.MPClockColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.Standby = ConfigSelection(choices = [("0", _("off")), ("1", _("on"))], default="1")
config.plugins.LCD4linux.StandbyScreenMax = ConfigSelection(choices = [("1", _("Screen 1")), ("2", _("Screen 1-2")), ("3", _("Screen 1-3"))], default="1")
config.plugins.LCD4linux.StandbyHelligkeit = ConfigSlider(default = 1,  limits = (0, 7))
config.plugins.LCD4linux.StandbyLCDoff = ConfigClock(default = ((5 * 60 + 0) * 60) )
config.plugins.LCD4linux.StandbyLCDon = ConfigClock(default = ((5 * 60 + 0) * 60) )
config.plugins.LCD4linux.StandbyClock = ConfigSelection(choices = ScreenSelect, default="1")
config.plugins.LCD4linux.StandbyClockLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyClockType = ConfigSelection(choices = [("1", _("Time")), ("2", _("Date+Time")), ("3", _("Date"))], default="1")
config.plugins.LCD4linux.StandbyClockSize = ConfigSlider(default = 110,  increment = 2, limits = (10, 150))
config.plugins.LCD4linux.StandbyClockPos = ConfigSlider(default = 100,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyClockAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="1")
config.plugins.LCD4linux.StandbyClockSplit = ConfigYesNo(default = False)
config.plugins.LCD4linux.StandbyClockColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.StandbyTimer = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.StandbyTimerLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyTimerSize = ConfigSlider(default = 22,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.StandbyTimerPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyTimerColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.StandbyWetter = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.StandbyWetterLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyWetterPos = ConfigSlider(default = 50,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyWetterType = ConfigSelection(choices = [("1", _("4 Days small")), ("2", _("4 Days big")), ("3", _("Current big")), ("4", _("Current full"))], default="1")
config.plugins.LCD4linux.StandbyText = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.StandbyTextLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyTextFile = ConfigText(default="/tmp/lcd4linux.txt", fixed_size=False)
config.plugins.LCD4linux.StandbyTextSize = ConfigSlider(default = 32,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.StandbyTextAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center"))], default="0")
config.plugins.LCD4linux.StandbyTextPos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyTextColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.StandbyTextBackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="0")
config.plugins.LCD4linux.StandbyText2 = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.StandbyText2LCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyText2File = ConfigText(default="/tmp/lcd4linux.txt", fixed_size=False)
config.plugins.LCD4linux.StandbyText2Size = ConfigSlider(default = 32,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.StandbyText2Align = ConfigSelection(choices = [("0", _("left")), ("1", _("center"))], default="0")
config.plugins.LCD4linux.StandbyText2Pos = ConfigSlider(default = 120,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyText2Color = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.StandbyText2BackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="0")
config.plugins.LCD4linux.StandbyHTTP = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.StandbyHTTPLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyHTTPURL = ConfigText(default="http://", fixed_size=False)
config.plugins.LCD4linux.StandbyHTTPSize = ConfigSlider(default = 20,  increment = 1, limits = (10, 100))
config.plugins.LCD4linux.StandbyHTTPPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyHTTPAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center")), ("2", _("right"))], default="0")
config.plugins.LCD4linux.StandbyHTTPColor = ConfigSelection(choices = Farbe, default="white")
config.plugins.LCD4linux.StandbyHTTPBackColor = ConfigSelection(choices = [("0", _("off"))] + Farbe, default="0")
config.plugins.LCD4linux.StandbyBild = ConfigSelection(choices = ScreenSelect, default="0")
config.plugins.LCD4linux.StandbyBildLCD = ConfigSelection(choices = LCDSelect, default="1")
config.plugins.LCD4linux.StandbyBildFile = ConfigText(default="/tmp/lcd4linux.jpg", fixed_size=False)
config.plugins.LCD4linux.StandbyBildSize = ConfigSlider(default = 240,  increment = 10, limits = (10, 800))
config.plugins.LCD4linux.StandbyBildPos = ConfigSlider(default = 0,  increment = 2, limits = (0, 600))
config.plugins.LCD4linux.StandbyBildAlign = ConfigSelection(choices = [("0", _("left")), ("1", _("center"))], default="0")

def OSDclose():
	global OSDon
	OSDon = 0
	print "[LCD4linux] Screen close"
	return

def replacement_Screen_show(self):
	global OSDon
	global OSDtimer
	print "[LCD4linux] Skin", self.skinName
	if self.skinName not in OSDdontskin and OSDtimer >= 0:
		if "Title" in self:
			ib = self["Title"].getText()
#			print "[LCD4linux] Screen", ib
			if ib not in OSDdontshow:
				print "[LCD4linux] Screen open", ib, self.skinName
				OSDon = 3
				self.onClose.append(OSDclose)
			else:
				OSDon = 0
		else:
			print "[LCD4linux] Screen open no Title", self.skinName
			OSDon = 3
			self.onClose.append(OSDclose)
	else:
		OSDon = 0
	Screen.show_old(self)

Screen.show_old = Screen.show
Screen.show = replacement_Screen_show

# get picon path
def getpiconres(x, y, ref):
	rr=str(""+ref)
	rr=rr.split("::")[0]
	if rr[-1] != ":":
		rr+=":"
	picon = str(rr.replace(":", "_")[:-1]) + ".png"
#	print "Picon", ref, picon
	if config.plugins.LCD4linux.PiconCache.value[-1:] != "/":
		config.plugins.LCD4linux.PiconCache.value += "/"
	# if we have an picon
	PD = ""
	if os.path.isfile(config.plugins.LCD4linux.PiconPath.value + picon):
		PD = config.plugins.LCD4linux.PiconPath.value + picon
	elif os.path.isfile(config.plugins.LCD4linux.PiconPathAlt.value + picon) and len(config.plugins.LCD4linux.PiconPathAlt.value) > 3:
		PD = config.plugins.LCD4linux.PiconPathAlt.value + picon
	if PD != "" and os.path.isdir(config.plugins.LCD4linux.PiconCache.value):
#		print "PICON: exists"
		# do we have a resized picon already?
		if not os.path.isfile(config.plugins.LCD4linux.PiconCache.value + picon):
			print "[LCD4linux] Resize Picon"
			try:
				file_in = PD
				pil_image = Image.open(file_in)
				# lcd is 320,240
				if config.plugins.LCD4linux.PiconAspectRatio.value != "0":
					xx,yy = pil_image.size
					y=int(float(x)/xx*yy)
				image_new = pil_image.resize((x, y), Image.ANTIALIAS) #BILINEAR)
				file_out = config.plugins.LCD4linux.PiconCache.value + picon
#				print "RESIZE write",file_out
				s = os.statvfs(config.plugins.LCD4linux.PiconCache.value)
				if (s.f_bsize * s.f_bavail / 1024) < 100:
					print "[LCD4linux] Error: Cache Directory near full"
					return ""			
				image_new.save(file_out)
			except:
				return ""			
#			print "PICON return",PIC
		return config.plugins.LCD4linux.PiconCache.value + picon
	else:
		# no picon for channel
		if not os.path.exists(config.plugins.LCD4linux.PiconCache.value):
			try:
				os.system("mkdir -p %s" % config.plugins.LCD4linux.PiconCache.value)
			except:
				print "[LCD4linux] PiconCache Error"
#		print "PICON: none"
		return ""

def writeHelligkeit(hell):
	f = open(PICbright, "w")
	f.write(str(hell) + "\r\n")
	f.close()
	
def getBilder():
	global Bilder
	global BilderStandby
	global BilderIndex
	global BilderIndexStandby
	if config.plugins.LCD4linux.StandbyBild.value !="0" or config.plugins.LCD4linux.Bild.value !=0:
		if os.path.isdir(config.plugins.LCD4linux.StandbyBildFile.value):
			BilderIndex = 0
			BilderStandby = glob.glob(os.path.normpath(config.plugins.LCD4linux.StandbyBildFile.value)+"/*.png")
			BilderStandby += glob.glob(os.path.normpath(config.plugins.LCD4linux.StandbyBildFile.value)+"/*.jpg")
			BilderStandby.sort()
		if os.path.isdir(config.plugins.LCD4linux.BildFile.value):
			BilderIndex = 0
			Bilder = glob.glob(os.path.normpath(config.plugins.LCD4linux.BildFile.value)+"/*.png")
			Bilder += glob.glob(os.path.normpath(config.plugins.LCD4linux.BildFile.value)+"/*.jpg")
			Bilder.sort()

def DemonRestart():
	from threading import Thread
	t = Thread(target=DemonRestartThread)
	t.start()

def DemonRestartThread():
	global DemonPID
	global LastDemon
	os.system("/etc/init.d/lcd4linux stop%s" % LastDemon)
	sleep(4)
	DPF = 0
	if config.plugins.LCD4linux.LCDType1.value[0] == "1":
		DPF += 1
	if config.plugins.LCD4linux.LCDType2.value[0] == "1":
		DPF += 1
	if DPF == 0:
		return
	LastDemon = "" if DPF == 2 else "1"
	os.system("/etc/init.d/lcd4linux start%s" % LastDemon)
	sleep(2)
	DemonPID = ["","","",""]
	if os.path.isfile("/var/run/lcd4linux1.pid"):
		f = open("/var/run/lcd4linux1.pid")
		DemonPID[0] = f.read()[:-1]
		f.close()
		DemonPID[2] = DemonStat("/proc/"+DemonPID[0]+"/stat", "?")
	if LastDemon == "":
		if os.path.isfile("/var/run/lcd4linux2.pid"):
			f = open("/var/run/lcd4linux2.pid")
			DemonPID[1] = f.read()[:-1]
			f.close()
			DemonPID[3] = DemonStat("/proc/"+DemonPID[1]+"/stat", "?")

def DemonUSB(p):
	if os.path.isdir(p):
		d = os.listdir(p)
		for i in range(len(d)):
			if os.path.realpath(p+"/"+d[i]).find("/usb/") > 0:
				return os.path.realpath(p+"/"+d[i])
	return ""

def DemonStat(p,ID):
	if os.path.isfile(p) and p.find("//") == -1:
		f = open(p)
		b = f.read().split(" ")
		f.close()
		print "[LCD4linux] Demon ID",b[23]
		if ID == "?":
			return b[23]
#		if b[23] != ID:
		if abs(int(b[23])-int(ID)) > 2:
			f = open("/tmp/LCD4log.txt","a")
			try:
				f.write(strftime("%d.%H:%M:%S ") + p + " " + ID + " -> " + b[23] + "\r\n")
			except:
				pass
			finally:
				f.close()
			return True
		return False
	return False

def DemonCheck():
	global DemonPID
#	print "DemonCheck", DemonPID
	p = DemonUSB("/proc/"+DemonPID[0]+"/fd")
	if p.find("deleted") > 0:
		print "[LCD4linux] Demon 1 failed"
		return True
	p = DemonUSB("/proc/"+DemonPID[1]+"/fd")
	if p.find("deleted") > 0:
		print "[LCD4linux] Demon 2 failed"
		return True
	if config.plugins.LCD4linux.DemonCheck.value == True:
		if DemonStat("/proc/"+DemonPID[0]+"/stat", DemonPID[2]):
			print "[LCD4linux] Demon 1 Stat failed", DemonPID[2]
			return True
		if DemonStat("/proc/"+DemonPID[1]+"/stat", DemonPID[3]):
			print "[LCD4linux] Demon 2 Stat failed", DemonPID[3]
			return True
	return False

def SamsungCheck():
	global SamsungDevice
	global SamsungDevice2
	if USBok == False:
		return False
	if config.plugins.LCD4linux.LCDType1.value[0] == "2":
		known_devices_list = Photoframe.get_known_devices()
		device0 = known_devices_list[(int(config.plugins.LCD4linux.LCDType1.value[1])-3)*2]
		if Photoframe.find_device(device0) is None:
			print "[LCD4linux] Samsung 1 Stat failed"
			SamsungDevice = None
			return True
	if config.plugins.LCD4linux.LCDType2.value[0] == "2":
		known_devices_list = Photoframe.get_known_devices()
		device0 = known_devices_list[(int(config.plugins.LCD4linux.LCDType2.value[1])-3)*2]
		if Photoframe.find_device(device0) is None:
			print "[LCD4linux] Samsung 2 Stat failed"
			SamsungDevice2 = None
			return True
	return False

def getSamsungDevice():
	global SamsungDevice
	global SamsungDevice2
	print "[LCD4linux] get Samsung Device" 
#	print config.plugins.LCD4linux.LCDType1.value, config.plugins.LCD4linux.LCDType2.value, USBok:
	if USBok == True:
		if config.plugins.LCD4linux.LCDType1.value[0] == "2":
			if SamsungDevice is None:
				print "[LCD4linux] get Samsung Device..." 
				known_devices_list = Photoframe.get_known_devices()
				device0 = known_devices_list[(int(config.plugins.LCD4linux.LCDType1.value[1])-3)*2]
				device1 = known_devices_list[(int(config.plugins.LCD4linux.LCDType1.value[1])-3)*2+1]
				SamsungDevice = Photoframe.init_device(device0, device1)
		if config.plugins.LCD4linux.LCDType2.value[0] == "2":
			if SamsungDevice2 is None:
				print "[LCD4linux] get Samsung2 Device..." 
				known_devices_list = Photoframe.get_known_devices()
				device0 = known_devices_list[(int(config.plugins.LCD4linux.LCDType2.value[1])-3)*2]
				device1 = known_devices_list[(int(config.plugins.LCD4linux.LCDType2.value[1])-3)*2+1]
				SamsungDevice2 = Photoframe.init_device(device0, device1)
		
class LCDdisplayConfig(ConfigListScreen,Screen):
	skin = """
			<screen position="center,center" size="600,400" title="LCD4linux Settings" >
			<widget name="config" position="0,0" size="600,330" scrollbarMode="showOnDemand" />
			<widget source="introduction" render="Label" position="5,335" size="580,30" zPosition="10" font="Regular;21" halign="center" valign="center" backgroundColor="#25062748" transparent="1" />
			
			<widget name="key_red" position="0,360" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18" transparent="1"/> 
			<widget name="key_green" position="140,360" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18" transparent="1"/> 
			<widget name="key_yellow" position="280,360" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18" transparent="1"/> 
			<widget name="key_blue" position="420,360" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18" transparent="1"/> 

			<widget source="Version" render="Label" position="560,350" size="60,20" zPosition="1" font="Regular;11" halign="left" valign="center" backgroundColor="#25062748" transparent="1" />
			<widget source="LibUSB" render="Label" position="560,370" size="60,20" zPosition="1" font="Regular;11" halign="left" valign="center" foregroundColor="red" backgroundColor="#25062748" transparent="1" />
			
			<ePixmap name="red"    position="0,360"   zPosition="2" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap name="green"  position="140,360" zPosition="2" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap name="yellow" position="280,360" zPosition="2" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap name="blue"   position="420,360" zPosition="2" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
		</screen>"""
		
	def __init__(self, session, args = 0):
		global ConfigMode
		global OSDon
		self.session = session
		Screen.__init__(self, session)
		ConfigMode = True
		OSDon = 0
		getBilder()
		self.SavePicon = config.plugins.LCD4linux.PiconType.value
		self.SavePiconSize = config.plugins.LCD4linux.PiconSize.value
		self.SaveAspectRatio = config.plugins.LCD4linux.PiconAspectRatio.value
		self.SaveWetter = config.plugins.LCD4linux.WetterCity.value
		self.SaveWetterType = config.plugins.LCD4linux.WetterType.value
		self.SaveStandbyWetterType = config.plugins.LCD4linux.StandbyWetterType.value
		self.SaveScreenActive = config.plugins.LCD4linux.ScreenActive.value
		self.Aktuell = " "
		self.list = []
	
		ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.selectionChanged)

		self["introduction"] = StaticText()
		self["Version"] = StaticText(Version)
		if USBok == False: 
			self["LibUSB"] = StaticText("libusb!")
		else:
			self["LibUSB"] = StaticText()
		
		self["key_red"] = Button(_("Cancel"))
		self["key_green"] = Button(_("Save"))
		self["key_yellow"] = Button(_("Restart Displays"))
		self["key_blue"] = Button("")
		self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"red": self.cancel,
			"green": self.save,
			"yellow": self.LCDrestart,
			"blue": self.Page,
			"save": self.save,
			"cancel": self.cancel,
			"ok": self.keyOK,
		}, -1)
		if not self.selectionChanged in self["config"].onSelectionChanged:
			self["config"].onSelectionChanged.append(self.selectionChanged)
		self.mode = "on"
		self.SetList()
		self.mode = "media"
		self.SetList()
		self.mode = "standby"
		self.SetList()
		self.mode = "global"
		self.SetList()
		self.mode = "standby"
		self.Page()
		self.selectionChanged()

	def SetList(self):
		if self.Aktuell.startswith("-"):
			return
		if self.mode == "global":
			self.list1 = []
			self.list1.append(getConfigListEntry(_("LCD4linux enabled"), config.plugins.LCD4linux.Enable))
			self.list1.append(getConfigListEntry(_("- Run as Thread/in Background"), config.plugins.LCD4linux.Thread))
			self.list1.append(getConfigListEntry(_("- LCD 1 Type"), config.plugins.LCD4linux.LCDType1))
			self.list1.append(getConfigListEntry(_("- LCD 1 Rotate"), config.plugins.LCD4linux.LCDRotate1))
			self.list1.append(getConfigListEntry(_("- LCD 2 Type"), config.plugins.LCD4linux.LCDType2))
			self.list1.append(getConfigListEntry(_("- LCD 2 Rotate"), config.plugins.LCD4linux.LCDRotate2))
			self.list1.append(getConfigListEntry(_("- Active Screen"), config.plugins.LCD4linux.ScreenActive))
			self.list1.append(getConfigListEntry(_("- Screens used for Changing"), config.plugins.LCD4linux.ScreenMax))
			self.list1.append(getConfigListEntry(_("- Screen 1 Changing Time"), config.plugins.LCD4linux.ScreenTime))
			self.list1.append(getConfigListEntry(_("- Screen 2 Changing Time"), config.plugins.LCD4linux.ScreenTime2))
			self.list1.append(getConfigListEntry(_("- Screen 3 Changing Time"), config.plugins.LCD4linux.ScreenTime3))
			self.list1.append(getConfigListEntry(_("- Screen 4 Changing Time"), config.plugins.LCD4linux.ScreenTime4))
			self.list1.append(getConfigListEntry(_("- Picture Changing Time"), config.plugins.LCD4linux.BilderTime))
			self.list1.append(getConfigListEntry(_("- Weather City"), config.plugins.LCD4linux.WetterCity))
			self.list1.append(getConfigListEntry(_("- Show Recording Corner"), config.plugins.LCD4linux.Recording))
			self.list1.append(getConfigListEntry(_("- lcd4liunx Process-Check"), config.plugins.LCD4linux.DemonCheck))
			self.list1.append(getConfigListEntry(_("- Brightnes"), config.plugins.LCD4linux.Helligkeit))
			self.list1.append(getConfigListEntry(_("- Refresh (s)"), config.plugins.LCD4linux.Refresh))
			self.list1.append(getConfigListEntry(_("- Display Delay (ms)"), config.plugins.LCD4linux.Delay))
			self.list1.append(getConfigListEntry(_("- Double-button switches"), config.plugins.LCD4linux.KeySwitch))
			self["config"].setList(self.list1)
		elif self.mode == "on":
			self.list2 = []
			self.list2.append(getConfigListEntry(_("- Backlight Off (disable set Off=On)"), config.plugins.LCD4linux.LCDoff))
			self.list2.append(getConfigListEntry(_("- Backlight On"), config.plugins.LCD4linux.LCDon))
			self.list2.append(getConfigListEntry(_("Picon"), config.plugins.LCD4linux.Picon))
			if config.plugins.LCD4linux.Picon.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.PiconLCD))
				self.list2.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.PiconType))
				self.list2.append(getConfigListEntry(_("- Picon Size"), config.plugins.LCD4linux.PiconSize))
				self.list2.append(getConfigListEntry(_("- Picon Path (press OK)"), config.plugins.LCD4linux.PiconPath))
				self.list2.append(getConfigListEntry(_("- Picon Path 2 (press OK)"), config.plugins.LCD4linux.PiconPathAlt))
				self.list2.append(getConfigListEntry(_("- Picon Cache Path (press OK)"), config.plugins.LCD4linux.PiconCache))
				self.list2.append(getConfigListEntry(_("- Picon keep Aspect Ratio"), config.plugins.LCD4linux.PiconAspectRatio))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.PiconAlign))
				self.list2.append(getConfigListEntry(_("- Text Size"), config.plugins.LCD4linux.PiconTextSize))
			self.list2.append(getConfigListEntry(_("Clock"), config.plugins.LCD4linux.Clock))
			if config.plugins.LCD4linux.Clock.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.ClockLCD))
				self.list2.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.ClockType))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.ClockSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.ClockPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.ClockAlign))
				self.list2.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.ClockSplit))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.ClockColor))
			self.list2.append(getConfigListEntry(_("Program Name"), config.plugins.LCD4linux.Channel))
			if config.plugins.LCD4linux.Channel.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.ChannelLCD))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.ChannelSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.ChannelPos))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.ChannelColor))
			self.list2.append(getConfigListEntry(_("Program Number"), config.plugins.LCD4linux.ChannelNum))
			if config.plugins.LCD4linux.ChannelNum.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.ChannelNumLCD))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.ChannelNumSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.ChannelNumPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.ChannelNumAlign))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.ChannelNumColor))
				self.list2.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.ChannelNumBackColor))
			self.list2.append(getConfigListEntry(_("Program Info"), config.plugins.LCD4linux.Prog))
			if config.plugins.LCD4linux.Prog.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.ProgLCD))
				self.list2.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.ProgType))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.ProgSize))
				self.list2.append(getConfigListEntry(_("- maximum Lines"), config.plugins.LCD4linux.ProgLines))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.ProgPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.ProgAlign))
				self.list2.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.ProgSplit))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.ProgColor))
			self.list2.append(getConfigListEntry(_("Next Program Info"), config.plugins.LCD4linux.ProgNext))
			if config.plugins.LCD4linux.ProgNext.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.ProgNextLCD))
				self.list2.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.ProgNextType))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.ProgNextSize))
				self.list2.append(getConfigListEntry(_("- maximum Lines"), config.plugins.LCD4linux.ProgNextLines))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.ProgNextPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.ProgNextAlign))
				self.list2.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.ProgNextSplit))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.ProgNextColor))
			self.list2.append(getConfigListEntry(_("Progress Bar"), config.plugins.LCD4linux.Progress))
			if config.plugins.LCD4linux.Progress.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.ProgressLCD))
				self.list2.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.ProgressType))
				self.list2.append(getConfigListEntry(_("- Size"), config.plugins.LCD4linux.ProgressSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.ProgressPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.ProgressAlign))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.ProgressColor))
			self.list2.append(getConfigListEntry(_("Informations"), config.plugins.LCD4linux.Info))
			if config.plugins.LCD4linux.Info.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.InfoLCD))
				self.list2.append(getConfigListEntry(_("- Tunerinfo"), config.plugins.LCD4linux.InfoTuner))
				self.list2.append(getConfigListEntry(_("- Sensors"), config.plugins.LCD4linux.InfoSensor))
				self.list2.append(getConfigListEntry(_("- Size"), config.plugins.LCD4linux.InfoSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.InfoPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.InfoAlign))
				self.list2.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.InfoSplit))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.InfoColor))
			self.list2.append(getConfigListEntry(_("Show next Timer Event"), config.plugins.LCD4linux.Timer))
			if config.plugins.LCD4linux.Timer.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.TimerLCD))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.TimerSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.TimerPos))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.TimerColor))
			self.list2.append(getConfigListEntry(_("Weather"), config.plugins.LCD4linux.Wetter))
			if config.plugins.LCD4linux.Wetter.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.WetterLCD))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.WetterPos))
				self.list2.append(getConfigListEntry(_("- Weather Type"), config.plugins.LCD4linux.WetterType))
			self.list2.append(getConfigListEntry(_("Show Textfile") , config.plugins.LCD4linux.Text))
			if config.plugins.LCD4linux.Text.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.TextLCD))
				self.list2.append(getConfigListEntry(_("- File"), config.plugins.LCD4linux.TextFile))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.TextSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.TextPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.TextAlign))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.TextColor))
				self.list2.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.TextBackColor))
			self.list2.append(getConfigListEntry(_("Show Textfile 2") , config.plugins.LCD4linux.Text2))
			if config.plugins.LCD4linux.Text2.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.Text2LCD))
				self.list2.append(getConfigListEntry(_("- File"), config.plugins.LCD4linux.Text2File))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.Text2Size))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.Text2Pos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.Text2Align))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.Text2Color))
				self.list2.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.Text2BackColor))
			self.list2.append(getConfigListEntry(_("Show HTTP Text") , config.plugins.LCD4linux.HTTP))
			if config.plugins.LCD4linux.HTTP.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.HTTPLCD))
				self.list2.append(getConfigListEntry(_("- URL"), config.plugins.LCD4linux.HTTPURL))
				self.list2.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.HTTPSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.HTTPPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.HTTPAlign))
				self.list2.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.HTTPColor))
				self.list2.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.HTTPBackColor))
			self.list2.append(getConfigListEntry(_("Show Picture") , config.plugins.LCD4linux.Bild))
			if config.plugins.LCD4linux.Bild.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.BildLCD))
				self.list2.append(getConfigListEntry(_("- File or Path"), config.plugins.LCD4linux.BildFile))
				self.list2.append(getConfigListEntry(_("- Size"), config.plugins.LCD4linux.BildSize))
				self.list2.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.BildPos))
				self.list2.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.BildAlign))
			self.list2.append(getConfigListEntry(_("OSD (display time)"), config.plugins.LCD4linux.OSD))
			if config.plugins.LCD4linux.OSD.value != "0":
				self.list2.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.OSDLCD))
				self.list2.append(getConfigListEntry(_("- OSD Size [425]"), config.plugins.LCD4linux.OSDsize))
				self.list2.append(getConfigListEntry(_("- Fast Grab, lower quality"), config.plugins.LCD4linux.OSDfast))
			self["config"].setList(self.list2)
		elif self.mode == "media":
			self.list3 = []
			self.list3.append(getConfigListEntry(_("- Screens used for Changing"), config.plugins.LCD4linux.MPScreenMax))
			self.list3.append(getConfigListEntry(_("Title"), config.plugins.LCD4linux.MPTitle))
			if config.plugins.LCD4linux.MPTitle.value != "0":
				self.list3.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.MPTitleLCD))
				self.list3.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.MPTitleSize))
				self.list3.append(getConfigListEntry(_("- maximum Lines"), config.plugins.LCD4linux.MPTitleLines))
				self.list3.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.MPTitlePos))
				self.list3.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.MPTitleAlign))
				self.list3.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.MPTitleSplit))
				self.list3.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.MPTitleColor))
			self.list3.append(getConfigListEntry(_("Infos"), config.plugins.LCD4linux.MPInfo1))
			if config.plugins.LCD4linux.MPInfo1.value != "0":
				self.list3.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.MPInfo1LCD))
				self.list3.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.MPInfo1Size))
				self.list3.append(getConfigListEntry(_("- maximum Lines"), config.plugins.LCD4linux.MPInfo1Lines))
				self.list3.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.MPInfo1Pos))
				self.list3.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.MPInfo1Align))
				self.list3.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.MPInfo1Split))
				self.list3.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.MPInfo1Color))
			self.list3.append(getConfigListEntry(_("Progress Bar"), config.plugins.LCD4linux.MPProgress))
			if config.plugins.LCD4linux.MPProgress.value != "0":
				self.list3.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.MPProgressLCD))
				self.list3.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.MPProgressType))
				self.list3.append(getConfigListEntry(_("- Size"), config.plugins.LCD4linux.MPProgressSize))
				self.list3.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.MPProgressPos))
				self.list3.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.MPProgressAlign))
				self.list3.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.MPProgressColor))
			self.list3.append(getConfigListEntry(_("Clock"), config.plugins.LCD4linux.MPClock))
			if config.plugins.LCD4linux.MPClock.value != "0":
				self.list3.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.MPClockLCD))
				self.list3.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.MPClockType))
				self.list3.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.MPClockSize))
				self.list3.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.MPClockPos))
				self.list3.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.MPClockAlign))
				self.list3.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.MPClockSplit))
				self.list3.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.MPClockColor))
			self["config"].setList(self.list3)
		elif self.mode == "standby":
			self.list4 = []
			self.list4.append(getConfigListEntry(_("Standby - LCD Display"), config.plugins.LCD4linux.Standby))
			self.list4.append(getConfigListEntry(_("- Screens used for Changing"), config.plugins.LCD4linux.StandbyScreenMax))
			self.list4.append(getConfigListEntry(_("- Brightnes"), config.plugins.LCD4linux.StandbyHelligkeit))
			self.list4.append(getConfigListEntry(_("- Backlight Off (disable set Off=On)"), config.plugins.LCD4linux.StandbyLCDoff))
			self.list4.append(getConfigListEntry(_("- Backlight On"), config.plugins.LCD4linux.StandbyLCDon))
			self.list4.append(getConfigListEntry(_("Standby - Clock"), config.plugins.LCD4linux.StandbyClock))
			if config.plugins.LCD4linux.StandbyClock.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyClockLCD))
				self.list4.append(getConfigListEntry(_("- Type"), config.plugins.LCD4linux.StandbyClockType))
				self.list4.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.StandbyClockSize))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyClockPos))
				self.list4.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.StandbyClockAlign))
				self.list4.append(getConfigListEntry(_("- Split Screen"), config.plugins.LCD4linux.StandbyClockSplit))
				self.list4.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.StandbyClockColor))
			self.list4.append(getConfigListEntry(_("Standby - Show next Timer Event"), config.plugins.LCD4linux.StandbyTimer))
			if config.plugins.LCD4linux.StandbyTimer.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyTimerLCD))
				self.list4.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.StandbyTimerSize))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyTimerPos))
				self.list4.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.StandbyTimerColor))
			self.list4.append(getConfigListEntry(_("Standby - Weather"), config.plugins.LCD4linux.StandbyWetter))
			if config.plugins.LCD4linux.StandbyWetter.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyWetterLCD))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyWetterPos))
				self.list4.append(getConfigListEntry(_("- Weather Type"), config.plugins.LCD4linux.StandbyWetterType))
			self.list4.append(getConfigListEntry(_("Standby - Show Textfile"), config.plugins.LCD4linux.StandbyText))
			if config.plugins.LCD4linux.StandbyText.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyTextLCD))
				self.list4.append(getConfigListEntry(_("- File"), config.plugins.LCD4linux.StandbyTextFile))
				self.list4.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.StandbyTextSize))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyTextPos))
				self.list4.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.StandbyTextAlign))
				self.list4.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.StandbyTextColor))
				self.list4.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.StandbyTextBackColor))
			self.list4.append(getConfigListEntry(_("Standby - Show Textfile 2"), config.plugins.LCD4linux.StandbyText2))
			if config.plugins.LCD4linux.StandbyText2.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyText2LCD))
				self.list4.append(getConfigListEntry(_("- File"), config.plugins.LCD4linux.StandbyText2File))
				self.list4.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.StandbyText2Size))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyText2Pos))
				self.list4.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.StandbyText2Align))
				self.list4.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.StandbyText2Color))
				self.list4.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.StandbyText2BackColor))
			self.list4.append(getConfigListEntry(_("Standby - Show HTTP Text") , config.plugins.LCD4linux.StandbyHTTP))
			if config.plugins.LCD4linux.StandbyHTTP.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyHTTPLCD))
				self.list4.append(getConfigListEntry(_("- URL"), config.plugins.LCD4linux.StandbyHTTPURL))
				self.list4.append(getConfigListEntry(_("- Font Size"), config.plugins.LCD4linux.StandbyHTTPSize))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyHTTPPos))
				self.list4.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.StandbyHTTPAlign))
				self.list4.append(getConfigListEntry(_("- Color"), config.plugins.LCD4linux.StandbyHTTPColor))
				self.list4.append(getConfigListEntry(_("- Background Color"), config.plugins.LCD4linux.StandbyHTTPBackColor))
			self.list4.append(getConfigListEntry(_("Standby - Show Picture") , config.plugins.LCD4linux.StandbyBild))
			if config.plugins.LCD4linux.StandbyBild.value != "0":
				self.list4.append(getConfigListEntry(_("- which LCD"), config.plugins.LCD4linux.StandbyBildLCD))
				self.list4.append(getConfigListEntry(_("- File or Path"), config.plugins.LCD4linux.StandbyBildFile))
				self.list4.append(getConfigListEntry(_("- Size"), config.plugins.LCD4linux.StandbyBildSize))
				self.list4.append(getConfigListEntry(_("- Position"), config.plugins.LCD4linux.StandbyBildPos))
				self.list4.append(getConfigListEntry(_("- Alignment"), config.plugins.LCD4linux.StandbyBildAlign))
			self["config"].setList(self.list4)

	def Page(self):
		self.Aktuell=" "
		if self.mode == "global":
			self.mode = "on"
			self.setTitle("LCD4linux Display-Mode On")
#			self["config"].setList(self.list2)
			self["key_blue"].setText("Set Media >>")
			self.SetList()
		elif self.mode == "on":
			self.mode = "media"
			self.setTitle("LCD4linux Display-Mode MediaPlayer")
#			self["config"].setList(self.list3)
			self["key_blue"].setText("Set Standby >>")
			self.SetList()
		elif self.mode == "media":
			self.mode = "standby"
			self.setTitle("LCD4linux Display-Mode Standby")
#			self["config"].setList(self.list4)
			self["key_blue"].setText("Set Global >>")
			self.SetList()
		elif self.mode == "standby":
			self.mode = "global"
			self.setTitle("LCD4linux Settings")
#			self["config"].setList(self.list1)
			self["key_blue"].setText("Set On >>")
			self.SetList()

	def keyOK(self):
		ConfigListScreen.keyOK(self)
		try:
			from Screens.LocationBox import LocationBox
			sel = self["config"].getCurrent()[1]
			if sel == config.plugins.LCD4linux.PiconPath:
				self.session.openWithCallback(self.dirSelected1, LocationBox, text = _("Choose path"), filename = "", currDir = self["config"].getCurrent()[1].value, minFree = 50)
			if sel == config.plugins.LCD4linux.PiconCache:
				self.session.openWithCallback(self.dirSelected2, LocationBox, text = _("Choose path"), filename = "", currDir = self["config"].getCurrent()[1].value, minFree = 50)
			if sel == config.plugins.LCD4linux.PiconPathAlt:
				self.session.openWithCallback(self.dirSelected3, LocationBox, text = _("Choose path"), filename = "", currDir = self["config"].getCurrent()[1].value, minFree = 50)
		except Exception, e:
			self.session.open(MessageBox, "Error:\n" + str(e), MessageBox.TYPE_ERROR)

	def dirSelected1(self, dir):
		if dir is not None and dir != "?":
			if dir[-1:] != "/":
				dir += "/"
			config.plugins.LCD4linux.PiconPath.value = dir

	def dirSelected2(self, dir):
		if dir is not None and dir != "?":
			if dir[-1:] != "/":
				dir += "/"
			config.plugins.LCD4linux.PiconCache.value = dir

	def dirSelected3(self, dir):
		if dir is not None and dir != "?":
			if dir[-1:] != "/":
				dir += "/"
			config.plugins.LCD4linux.PiconPathAlt.value = dir

	def selectionChanged(self):
		global ConfigStandby
		global wwwWetter
		global ScreenActive
		global isMediaPlayer
#		print "--------", self.getCurrentValue()
#		print "--------", self["config"].getCurrent()[0]
#		sel = self["config"].getCurrent()[1]
		self.Aktuell = self["config"].getCurrent()[0]
		self["introduction"].setText(_("Current value: %s") % (self.getCurrentValue()))
		if self.mode == "standby":
			ConfigStandby = True
		elif self.mode == "media":
			isMediaPlayer = "config"
		else:
			ConfigStandby = False
			isMediaPlayer = ""
		if config.plugins.LCD4linux.PiconPath.value == config.plugins.LCD4linux.PiconCache.value:
			config.plugins.LCD4linux.PiconCache.value = "/usr/share/enigma2/piconcache/"
		if self.SavePicon != config.plugins.LCD4linux.PiconType.value or self.SavePiconSize != config.plugins.LCD4linux.PiconSize.value or self.SaveAspectRatio != config.plugins.LCD4linux.PiconAspectRatio.value:
			self.SavePiconSize = config.plugins.LCD4linux.PiconSize.value
			self.SavePicon = config.plugins.LCD4linux.PiconType.value
			self.SaveAspectRatio = config.plugins.LCD4linux.PiconAspectRatio.value
			os.system("rm -f %s" % config.plugins.LCD4linux.PiconCache.value + "*.png")
		if self.SaveWetter != config.plugins.LCD4linux.WetterCity.value or self.SaveWetterType != config.plugins.LCD4linux.WetterType.value or self.SaveStandbyWetterType != config.plugins.LCD4linux.StandbyWetterType.value:
			self.SaveWetter = config.plugins.LCD4linux.WetterCity.value
			self.SaveWetterType = config.plugins.LCD4linux.WetterType.value
			self.SaveStandbyWetterType = config.plugins.LCD4linux.StandbyWetterType.value
			wwwWetter = ""
		if self.SaveScreenActive != config.plugins.LCD4linux.ScreenActive.value:
			self.SaveScreenActive = config.plugins.LCD4linux.ScreenActive.value
			ScreenActive = self.SaveScreenActive
		if config.plugins.LCD4linux.BildFile.isChanged() or config.plugins.LCD4linux.StandbyBildFile.isChanged():
			getBilder()
		return

	def getCurrentValue(self):
		return str(self["config"].getCurrent()[1].getText())

	def LCDrestart(self):
		pass
		'''
		global SamsungDevice
		global SamsungDevice2
		DemonRestart()
		SamsungDevice = None
		SamsungDevice2 = None
		getSamsungDevice()
		'''

	def save(self):
		global ConfigMode
		global ConfigStandby
		global isMediaPlayer
		getBilder()
		'''
		if config.plugins.LCD4linux.Refresh.isChanged():
			f = open(DPFrefreshrate, "w")
			f.write(str(config.plugins.LCD4linux.Refresh.value * 1000) + "\r\n")
			f.close()
			self.LCDrestart()
		'''

		self["config"].setList(self.list1)
		for x in self["config"].list:
			x[1].save()
		self["config"].setList(self.list2)
		for x in self["config"].list:
			x[1].save()
		self["config"].setList(self.list3)
		for x in self["config"].list:
			x[1].save()
		self["config"].setList(self.list4)
		for x in self["config"].list:
			x[1].save()
		self.close(True,self.session)
		ConfigMode = False
		ConfigStandby = False
		isMediaPlayer = ""

	def cancel(self):
		global ConfigMode
		global ConfigStandby
		global isMediaPlayer
		self["config"].setList(self.list1)
		for x in self["config"].list:
			x[1].cancel()
		self["config"].setList(self.list2)
		for x in self["config"].list:
			x[1].cancel()
		self["config"].setList(self.list3)
		for x in self["config"].list:
			x[1].cancel()
		self["config"].setList(self.list4)
		for x in self["config"].list:
			x[1].cancel()
		self.close(True,self.session)
		ConfigMode = False
		ConfigStandby = False
		isMediaPlayer = ""

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.SetList()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.SetList()

#	def KeyUp(self):
#		WidgetVariableList.KeyLeft(self)
#		WidgetVariableList.KeyUp(self)

#	def KeyDown(self):
#		WidgetVariableList.KeyRight(self)
#		WidgetVariableList.KeyDown(self)


class UpdateStatus(Screen):
	def __init__(self, session):
		global ScreenActive
		Screen.__init__(self, session)

		ScreenActive = config.plugins.LCD4linux.ScreenActive.value
		self.SaveTXTfile = 0
		self.SaveBildfile = 0
		self.SaveStandbyBildfile = 0
		self.SaveStandbyTXTfile = 0
		self.KeyDoppel = 0
		self.KeyTime = 0
		self.StandbyChanged = False
		self.DataMinute = ""
		self.ref = ""

		self.StatusTimer = eTimer()
		self.StatusTimer.callback.append(self.updateStatus)

		self.ServiceTimer = eTimer()
		self.ServiceTimer.callback.append(self.ServiceChange)

		self.DemonTimer = eTimer()
		self.DemonTimer.callback.append(self.Demon)

		self.SamsungTimer = eTimer()
		self.SamsungTimer.callback.append(self.SamsungStart)

		self.__event_tracker = ServiceEventTracker(screen = self, eventmap =
			{
				iPlayableService.evUpdatedInfo: self.restartTimer,
				iPlayableService.evUpdatedEventInfo: self.restartTimer
#				iPlayableService.evSeekableStatusChanged: self.restartTimer,
#				iPlayableService.evVideoProgressiveChanged: self.restartTimer,
#				iPlayableService.evUser: self.restartTimer
			})

		eActionMap.getInstance().bindAction('', -0x7FFFFFFF, self.rcKeyPressed)
		self.recordtimer = session.nav.RecordTimer
		self.LastTimerlistUpdate = 0

		self.timerlist = ""
		self.pluginlist = ""

		self.pngutilconnect = pngutil.connect()

#####		self.onShow.append(self.ServiceChange)
#		config.misc.standbyCounter.addNotifier(self.restartTimer(self), initial_call = False)
		getBilder()
		self.StatusTimer.startLongTimer(5)
#		self.StatusTimer.start(200)
#		self.Demon()
#		self.SamsungStart()
		
	def updateStatus(self):
		print "[LCD4linux] update"

#		global DataMinute
#		global ScreenActive
		global BilderTime
		global OSDtimer
		global OSDon
		global isVideoPlaying
		self.StatusTimer.stop()
		SaveScreenActive = ScreenActive
#		print "Desktop",getDesktop(0).size().width()
		if config.plugins.LCD4linux.Text.value != "0":
			if os.path.isfile(config.plugins.LCD4linux.TextFile.value):
				if self.SaveTXTfile != os.path.getmtime(config.plugins.LCD4linux.TextFile.value):
					self.SaveTXTfile = os.path.getmtime(config.plugins.LCD4linux.TextFile.value)
					self.restartTimer()
		if config.plugins.LCD4linux.StandbyText.value != "0":
			if os.path.isfile(config.plugins.LCD4linux.StandbyTextFile.value):
				if self.SaveStandbyTXTfile != os.path.getmtime(config.plugins.LCD4linux.StandbyTextFile.value):
					self.SaveStandbyTXTfile = os.path.getmtime(config.plugins.LCD4linux.StandbyTextFile.value)
					self.restartTimer()
		if config.plugins.LCD4linux.Bild.value != "0":
			if os.path.isfile(config.plugins.LCD4linux.BildFile.value):
				if self.SaveBildfile != os.path.getmtime(config.plugins.LCD4linux.BildFile.value):
					self.SaveBildfile = os.path.getmtime(config.plugins.LCD4linux.BildFile.value)
					self.restartTimer()
			else:
				if self.SaveBildfile != 0:
					self.SaveBildfile = 0
					self.restartTimer()
		if config.plugins.LCD4linux.StandbyBild.value != "0":
			if os.path.isfile(config.plugins.LCD4linux.StandbyBildFile.value):
				if self.SaveStandbyBildfile != os.path.getmtime(config.plugins.LCD4linux.StandbyBildFile.value):
					self.SaveStandbyBildfile = os.path.getmtime(config.plugins.LCD4linux.StandbyBildFile.value)
					self.restartTimer()
			else:
				if self.SaveStandbyBildfile != 0:
					self.SaveStandbyBildfile = 0
					self.restartTimer()
		if config.plugins.LCD4linux.ScreenTime.value != "0":
			self.NextScreen()
		if config.plugins.LCD4linux.BilderTime.value != "0":
			if BilderTime >= int(config.plugins.LCD4linux.BilderTime.value):
				BilderTime=0
			BilderTime += 1
		if config.plugins.LCD4linux.OSD.value != "0":
			if OSDtimer < 0:
				OSDon = 0
				OSDtimer += 1
			if OSDon >= 2:
				if OSDtimer >= int(config.plugins.LCD4linux.OSD.value):
					OSDtimer = 0
					OSDon = 1
				OSDtimer += 1
		if isVideoPlaying !=0:
			isVideoPlaying+=1
			
#		print "--------",isVideoPlaying, isMediaPlayer, ConfigMode, ScreenActive
#		print BilderTime, OSDon,self.StandbyChanged,Standby.inStandby
		if strftime("%M")!=self.DataMinute or BilderTime == 1 or self.StandbyChanged != Standby.inStandby or ConfigMode or (ScreenActive != SaveScreenActive) or isVideoPlaying > 2 or OSDon == 3:
			print "[LCD4linux] Data-Build"
#			if config.plugins.LCD4linux.LCDType1.value[0] == "1" or config.plugins.LCD4linux.LCDType2.value[0] == "1":
#				if strftime("%M")!=self.DataMinute:
#					if DemonCheck():
#						self.Demon()
#					if SamsungCheck():
#						self.SamsungStart()
			self.DataMinute = strftime("%M")
			self.StandbyChanged = Standby.inStandby 
			self.restartTimer()
			if config.plugins.LCD4linux.StandbyWetter.value != "0" or config.plugins.LCD4linux.Wetter.value != "0":
				if strftime("%M") == "15" or strftime("%M") == "45" or wwwWetter.find("forecast_information") < 1:
					self.downloadWetter()
		if ConfigMode == True:
			self.StatusTimer.startLongTimer(5)
		else:
			self.StatusTimer.startLongTimer(5)

	def restartTimer(self):
		global OSDon
		self.ServiceTimer.stop()
		if OSDon == 2 and config.plugins.LCD4linux.OSDfast.value == False:
			self.ServiceTimer.start(config.plugins.LCD4linux.Delay.value+500, True)
		else:
			self.ServiceTimer.start(config.plugins.LCD4linux.Delay.value, True)

	def ServiceChange(self):
		global ThreadRunning
		global ScreenActive
		global ScreenTime
		global isMediaPlayer
		sref = self.session.nav.getCurrentlyPlayingServiceReference()
		if sref is not None:
			sref = sref.toString()
#			print "[LCD4linux] Service", sref
			if self.ref != sref:
				self.ref = sref
				ScreenActive = "1"
				ScreenTime = 0
				isMediaPlayer = ""
				if sref.startswith("1:0:2") is True:
					print "[LCD4linux] detected Radio"
					isMediaPlayer = "radio"
				elif sref.find("0:0:0:0:0:0:0:0:0:") >= 0:
					print "[LCD4linux] play Video"
					isMediaPlayer = "record"
				elif sref.startswith("4097:0") is True:
					print "[LCD4linux] detected AudioMedia"
					isMediaPlayer = "mp3"
					
#			service = self.session.nav.getCurrentService()
#			if service is not None:
#				print service.info().getName()
##				print service.info()
#				print service.info().getInfoString(iServiceInformation.sTagTitle)
##				print service.info().getInfoString(iServiceInformation.sTagAlbum)
#				print service.info().getInfoString(iServiceInformation.sTagArtist)
#				print service.info().getInfoString(iServiceInformation.sTagGenre)
##				print service.info().getInfoString(iServiceInformation.sTagDate)
##				print service.info().getInfoString(iServiceInformation.sDescription)
##				print service.info().getInfoString(iServiceInformation.sCurrentTitle)
##				print service.info().getInfoString(iServiceInformation.sNamespace)
##				print service.info().getInfoString(iServiceInformation.sProvider)
##	if servicerefstr.find("0:0:0:0:0:0:0:0:0:") is not -1 and not servicerefstr.startswith("4369:") and not servicerefstr.startswith("4097:") and not servicerefstr.startswith("4114:") and not servicerefstr.startswith("1:0:19:") and servicerefstr.startswith("1:0:") is False and not servicerefstr.endswith(".mpg") and not servicerefstr.endswith(".vob") and not servicerefstr.endswith(".avi") and not servicerefstr.endswith(".divx") and not servicerefstr.endswith(".mv4") and not servicerefstr.endswith(".mkv") and not servicerefstr.endswith(".mp4") and not servicerefstr.endswith(".ts"):


		if config.plugins.LCD4linux.Thread.value == True:
			if ThreadRunning > 0:
				ThreadRunning+= 1
				if ThreadRunning > 30:
					ThreadRunning = 0
				self.restartTimer()
				print "[LCD4linux] Thread already running"
				return
			from threading import Thread
			ThreadRunning = 1
			t = Thread(target=LCD4linuxPICThread, args=(self,session))
			t.start()
		else:
			LCD4linuxPIC(self,session)

	def rcKeyPressed(self, key, flag):
		global OSDon
		global OSDtimer
		global LCDon
		global ScreenTime
#		print "[LCD4linux] key", key, flag, self.KeyDoppel
		if config.plugins.LCD4linux.KeySwitch.value == True:
			if time()-self.KeyTime > 2 or isMediaPlayer == True:
				self.KeyDoppel = 0
			self.KeyTime = time()
			if self.KeyDoppel == key and flag == 0:
				self.KeyDoppel = 0
				if key == 165:
					LCDon = True if LCDon == False else False
				elif key == 163:
					ScreenTime = 9999
					self.NextScreen()
					self.restartTimer()
			elif flag == 0:
				self.KeyDoppel = key
			if key == 165 or key == 163:
				return 0
		if OSDon != 0:
			self.restartTimer()
			OSDon = 2
			OSDtimer = 0
		return 0

	def Demon(self):
		global LastDemon
		self.DemonTimer.stop()
		DPF = 0
		if config.plugins.LCD4linux.LCDType1.value[0] == "1":
			DPF += 1
		if config.plugins.LCD4linux.LCDType2.value[0] == "1":
			DPF += 1
		if not os.path.isfile("/etc/init.d/lcd4linux") or DPF == 0:
			print "[LCD4linux] no Daemon-Start-Script"
			return
		if os.path.isfile("/proc/bus/usb/devices"):
			gefunden = False
			FCfile = open("/proc/bus/usb/devices", "r")
			i = FCfile.read()
			FCfile.close()
			pos = i.find("Vendor=1908 ProdID=0102")
			if pos > 0:
				gefunden = True
			if (DPF == 2) and gefunden:
				if i.find("Vendor=1908 ProdID=0102", pos+10) > 0:
					gefunden = True
				else:
					gefunden = False
			if gefunden:
				DemonRestart()
			else:
				self.DemonTimer.startLongTimer(10)

	def SamsungStart(self):
		getSamsungDevice()
		if SamsungDevice is None:
			if config.plugins.LCD4linux.LCDType1.value[0] == "2":
				print "[LCD4linux] Samsung Device not found" 
				self.SamsungTimer.startLongTimer(10)
		else:
			print "[LCD4linux] Samsung Device ok" 
		if SamsungDevice2 is None:
			if config.plugins.LCD4linux.LCDType2.value[0] == "2":
				print "[LCD4linux] Samsung2 Device not found" 
				self.SamsungTimer.startLongTimer(10)
		else:
			print "[LCD4linux] Samsung2 Device ok" 

	def NextScreen(self):
		global ScreenActive
		global ScreenTime
		if ScreenActive == "1":
			ST = config.plugins.LCD4linux.ScreenTime.value
		elif ScreenActive == "2":
			ST = config.plugins.LCD4linux.ScreenTime2.value
		elif ScreenActive == "3":
			ST = config.plugins.LCD4linux.ScreenTime3.value
		elif ScreenActive == "4":
			ST = config.plugins.LCD4linux.ScreenTime4.value
		if ScreenTime >= int(ST):
			ScreenTime=0
			ScreenActive = str(int(ScreenActive)+1)
			if Standby.inStandby or ConfigStandby:
				if int(ScreenActive) > int(config.plugins.LCD4linux.StandbyScreenMax.value):
					ScreenActive = "1"
			elif isMediaPlayer != "":
				if int(ScreenActive) > int(config.plugins.LCD4linux.MPScreenMax.value):
					ScreenActive = "1"
			else:
				if int(ScreenActive) > int(config.plugins.LCD4linux.ScreenMax.value):
					ScreenActive = "1"
		ScreenTime += 1

	def downloadWetter(self):
		print "[LCD4linux] Wetterdownloadstart"
		self.feedurl = "http://www.google.com/ig/api?weather=%s&oe=utf-8&hl=%s" % (config.plugins.LCD4linux.WetterCity.value,language.getLanguage()[:2])
#		self.feedurl = "http://www.google.com/ig/api?weather=%s&oe=utf-8&hl=%s" % (config.plugins.LCD4linux.WetterCity.value,"de")
		getPage(self.feedurl).addCallback(self.downloadListCallback).addErrback(self.downloadListError)

	def downloadListError(self, error=""):
		print str(error)
#		self.session.open(MessageBox, "Error downloading Feed:\n%s" % str(error), type=MessageBox.TYPE_ERROR)

	def downloadListCallback(self, page=""):
		global wwwWetter
		wwwWetter = page
		wwwWetter = wwwWetter.replace('\xc2\x86', '').replace('\xc2\x87', '').replace('\n','').decode("utf-8", "ignore").encode("utf-8") or ""
		wwwWetter=codecs.decode(wwwWetter, 'UTF-8')
		if os.path.isfile(PICwetter):
			os.system("rm -f %s" % PICwetter)

def LCD4linuxPICThread(self,session):
	global ThreadRunning
	LCD4linuxPIC(self,session)
	ThreadRunning = 0


def getNumber(actservice):
	# actservice must be an instance of eServiceReference
	from Screens.InfoBar import InfoBar
	Servicelist = None
	if InfoBar and InfoBar.instance:
		Servicelist = InfoBar.instance.servicelist
	mask = (eServiceReference.isMarker | eServiceReference.isDirectory)
	number = 0
	bouquets = Servicelist and Servicelist.getBouquetList()
	if bouquets:
		#TODO get alternative for actbouquet
		actbouquet = Servicelist.getRoot()
		serviceHandler = eServiceCenter.getInstance()
		for name, bouquet in bouquets:
			if not bouquet.valid(): #check end of list
				break
			if bouquet.flags & eServiceReference.isDirectory:
				servicelist = serviceHandler.list(bouquet)
				if not servicelist is None:
					while True:
						service = servicelist.getNext()
						if not service.valid(): #check end of list
							break
						playable = not (service.flags & mask)
						if playable:
							number += 1
						if actbouquet:
							if actbouquet == bouquet and actservice == service:
								return number
						else:
							if actservice == service:
								return number
	return None

def getServiceInfo(self,NowNext):
	self.epgcache = eEPGCache.getInstance()
	event_begin = 0
	event_end = 0
	duration = 0
	event_name = ""
	if self.epgcache is not None:
		sref = self.session.nav.getCurrentlyPlayingServiceReference()
		if sref is not None:
			event = self.epgcache.lookupEvent(['IBDCTSERNX', (sref.toString(), NowNext, -1)])
			event_begin = 0
			if event:
				if event[0][4]:
					t = event[0][1]
					duration = event[0][2]
					event_name = event[0][4]
					event_begin = t
					event_end = event_begin + duration
				else:
					service = self.session.nav.getCurrentService()
					info = service and service.info()
					event = info and info.getEvent(NowNext)
					if event:
						event_name = event.getEventName()
						event_begin = event.getBeginTime()
						duration = event.getDuration()
						event_end = event_begin + duration
	return event_begin, event_end, duration, event_name

def getResolution(t):
	if t[1] == "0":
		MAX_W,MAX_H = 400,240
	elif t[1] == "1":
		MAX_W,MAX_H = 320,240
	elif t[1] == "2":
		MAX_W,MAX_H = 240,320
	elif t[1] == "3":
		MAX_W,MAX_H = 800,480
	elif t[1] == "4":
		MAX_W,MAX_H = 800,480
	elif t[1] == "5":
		MAX_W,MAX_H = 800,480
	elif t[1] == "6":
		MAX_W,MAX_H = 800,600
	elif t[1] == "7":
		MAX_W,MAX_H = 1024,600
	return MAX_W,MAX_H

def getSplit(ConfigSplit,ConfigAlign,MAX_W,w):
	POSX = (MAX_W-w)/2
	if ConfigSplit == False:
		if w > MAX_W or ConfigAlign == "0":
			POSX = 0
		elif ConfigAlign == "2":
			POSX = (MAX_W-w)
	else:
		if ConfigAlign == "1":
			POSX = POSX+(MAX_W/2)
		elif ConfigAlign == "2":
			POSX = MAX_W+POSX
	return POSX

def writeMultiline(sts,ConfigSize,ConfigPos,ConfigLines,ConfigColor,ConfigAlign,ConfigSplit,draw,im):
	MAX_W,MAX_H = im.size
	if ConfigSplit == True:
		MAX_W = int(MAX_W/2)
	sts = sts.replace('\xc2\x86', '').replace('\xc2\x87', '').decode("utf-8", "ignore").encode("utf-8") or ""
	astr = codecs.decode(sts, 'UTF-8')
	lines = astr.split("\n")
	lists = (textwrap.TextWrapper(width=int(MAX_W*2/ConfigSize), break_long_words=False).wrap(line) for line in lines)
	body  = "\n".join("\n".join(list) for list in lists)
	para = string.split(body, '\n')

	current_h=ConfigPos
	while len(para) > int(ConfigLines):
		del para[len(para)-1]
	for line in para:
		font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
		w,h = draw.textsize(line, font=font)
		TextSize = ConfigSize
		while w > MAX_W:
			TextSize -= 1
			font = ImageFont.truetype(FONT, TextSize, encoding='unic')
			w,h = draw.textsize(line, font=font)
		POSX = getSplit(ConfigSplit,ConfigAlign,MAX_W,w)
		draw.text((POSX, current_h), line, font=font, fill=ConfigColor)
		current_h+=h

def LCD4linuxPIC(self,session):
	global wwwWetter
	global Bilder
	global BilderStandby
	global BilderIndex
	global BilderIndexStandby
	global BilderTime
	global OSDon

# Google Wetter
	def putWetter(ConfigPos, ConfigType, draw, im):
		global WetterType
		if os.path.isfile(PICwetter) and ConfigType == WetterType:
			pil_image = Image.open(PICwetter)
			im.paste(pil_image,(0,ConfigPos))
		else:
			WetterType=ConfigType
			POSX, POSY = 1,0
			MAX_W,MAX_H = 320,80
			Wmulti = 1.4 if ConfigType != "1" else 1
			if ConfigType == "2":
				MAX_H = 220
				POSX = 10
			elif ConfigType == "3":
				MAX_H = 90
				POSY = POSY-(20*Wmulti)+1
			elif ConfigType == "4":
				Wmulti = 3.5
				MAX_H = 220
				POSY = POSY-(20*Wmulti)+1
			imW = Image.new('RGB', (MAX_W, MAX_H), (0, 0, 0, 0))
			drawW = ImageDraw.Draw(imW)
			dom = parseString(wwwWetter)
			for node in dom.getElementsByTagName('forecast_information'):
				for unitsystem in node.getElementsByTagName('unit_system'):
					UnitSystem = unitsystem.getAttribute('data')
			if ConfigType != "3" and ConfigType != "4":
				font = ImageFont.truetype(FONT,20*Wmulti, encoding='unic')
				Day="?"
				High="?"
				Low="?"
				Icon=""
				for node in dom.getElementsByTagName('forecast_conditions'):
					for day_of_week in node.getElementsByTagName('day_of_week'):
						Day = day_of_week.getAttribute('data')
					for high in node.getElementsByTagName('high'):
						High = high.getAttribute('data')
						if UnitSystem == "US":
							High = str(int((int(High)-32)*5/9))
					for low in node.getElementsByTagName('low'):
						Low = low.getAttribute('data')
						if UnitSystem == "US":
							Low = str(int((int(Low)-32)*5/9))
					for icon in node.getElementsByTagName('icon'):
						Icon = os.path.basename(icon.getAttribute('data'))
#					print "WetterData", Day, Low, High, Icon
					if os.path.isfile(WetterPath + Icon) and Icon.find("gif") > 1:
						pil_image = Image.open(WetterPath + Icon)
						if Wmulti != 1:
							pil_image = pil_image.resize((int(40*Wmulti), int(40*Wmulti)), Image.ANTIALIAS) #BILINEAR)
#						x,y=pil_image.size
						imW.paste(pil_image,(POSX,POSY+(20*Wmulti)))
					w,h = drawW.textsize(Day, font=font)
					drawW.text((POSX, POSY), Day, font=font)
					drawW.text((POSX, POSY+(60*Wmulti)), Low, font=font, fill="aquamarine")
					drawW.text((POSX+(25*Wmulti), POSY+(60*Wmulti)), High, font=font, fill="violet")
				
					POSX += (54*Wmulti)
				if Wmulti != 1:
					POSX = 10
					POSY += 90
				
			Hum = "?"
			Wind = "?"
			Temp_c = "?"
			Icon=""
			for node in dom.getElementsByTagName('current_conditions'):
				for temp_c in node.getElementsByTagName('temp_c'):
					Temp_c = temp_c.getAttribute('data') + "\xc2\xb0C"
				for hum in node.getElementsByTagName('humidity'):
					Hum1 = hum.getAttribute('data').replace("\xc2\xa0","").replace(" ","")
					Hum1 = Hum1.split(":")
					if len(Hum1) == 2:	
						Hum = Hum1[len(Hum1)-1].lstrip()
				for wind in node.getElementsByTagName('wind_condition'):
					Wind = wind.getAttribute('data')
					Wind = Wind.split(":")
					if len(Wind) == 2:
						Wind = Wind[len(Wind)-1].lstrip()
				for icon in node.getElementsByTagName('icon'):
					Icon = os.path.basename(icon.getAttribute('data'))
#				print "Temp, Hum", Temp_c, Hum, Wind, Icon
				if os.path.isfile(WetterPath + Icon) and Icon.find("gif") > 1:
					pil_image = Image.open(WetterPath + Icon)
					if Wmulti != 1:
						pil_image = pil_image.resize((int(40*Wmulti), int(40*Wmulti)), Image.ANTIALIAS) #BILINEAR)
#					x,y=pil_image.size
					if ConfigType == "4":
						POSX = 10
					imW.paste(pil_image,(POSX,POSY+(20*Wmulti)))
				if ConfigType == "4":
					font = ImageFont.truetype(FONT,(10*Wmulti), encoding='unic')
				else:
					font = ImageFont.truetype(FONT,(15*Wmulti), encoding='unic')
				minus5 = 0 if Wmulti != 1 else 5
				drawW.text((POSX-minus5, POSY+(64*Wmulti)), Wind, font=font, fill="silver")
				if ConfigType == "4":
					font = ImageFont.truetype(FONT,(20*Wmulti), encoding='unic')
				else:
					font = ImageFont.truetype(FONT,(25*Wmulti), encoding='unic')
				drawW.text((POSX+(45*Wmulti), POSY+(16*Wmulti)), Temp_c, font=font, fill="violet")
				if len(Hum)>3:
					if ConfigType == "4":
						font = ImageFont.truetype(FONT,(16*Wmulti), encoding='unic')
					else:
						font = ImageFont.truetype(FONT,(22*Wmulti), encoding='unic')
				drawW.text((POSX+(45*Wmulti), POSY+(37*Wmulti)), Hum, font=font, fill="silver")
			imW.save(PICwetter)
			im.paste(imW,(0,ConfigPos))
		return

# Text File
	def putTextFile(ConfigPos, ConfigSize, ConfigAlign, ConfigColor, ConfigBackColor, TextFile, draw, im):
		if ConfigMode==True and os.path.isfile(TextFile) == False:
			if os.path.isfile(TXTdemo) == False:
				f = open(TXTdemo,"w")
				f.write("demo line 1\ndemotext")
				f.close()
			TextFile = TXTdemo
		if os.path.isfile(TextFile):
			MAX_W,MAX_H = im.size
			current_h=ConfigPos
			font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
			f = open(TextFile,"r")
			for line in f.readlines():
				line = line.replace('\xc2\x86', '').replace('\xc2\x87', '').replace('\n','').decode("utf-8", "ignore").encode("utf-8") or ""
				line = codecs.decode(line, 'UTF-8')
				w,h = draw.textsize(line, font=font)
				POSX = getSplit(False,ConfigAlign,MAX_W,w)
				if ConfigBackColor !="0":
					draw.rectangle((POSX, current_h,POSX+w, current_h+h),fill=ConfigBackColor)
				draw.text((POSX, current_h), line, font=font, fill=ConfigColor)
				current_h+=h
			f.close()

# HTTP Text
	def putHTTP(ConfigPos, ConfigSize, ConfigAlign, ConfigColor, ConfigBackColor, HTTPurl, draw, im):
		t = ["not found"]
		try:
			r = urllib.urlopen(HTTPurl)
			t = r.read().split("\n")
			r.close()
		except:
			pass 
		finally:
			MAX_W,MAX_H = im.size
			current_h=ConfigPos
			font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
			for line in t:
				line = line.replace('\xc2\x86', '').replace('\xc2\x87', '').replace('\n','').decode("utf-8", "ignore").encode("utf-8") or ""
				line = codecs.decode(line, 'UTF-8')
				w,h = draw.textsize(line, font=font)
				POSX = getSplit(False,ConfigAlign,MAX_W,w)
				if ConfigBackColor !="0":
					draw.rectangle((POSX, current_h,POSX+w, current_h+h),fill=ConfigBackColor)
				draw.text((POSX, current_h), line, font=font, fill=ConfigColor)
				current_h+=h
	
# Clock
	def putClock(ConfigPos, ConfigSize, ConfigAlign, ConfigSplit, ConfigType, ConfigColor, draw, im):
		MAX_W,MAX_H = im.size
		if ConfigSplit == True:
			MAX_W = int(MAX_W/2)
		pp=ConfigPos
		if ConfigType == "2" or ConfigType == "3":
			now = strftime("%d.%m.%Y")
			font = ImageFont.truetype(FONT, int(ConfigSize/2), encoding='unic')
			w,h = draw.textsize(now, font=font)
			lx = getSplit(ConfigSplit,ConfigAlign,MAX_W,w)
			draw.text((lx, pp), now, font=font, fill=ConfigColor)
			pp+=h
		if ConfigType == "1" or ConfigType == "2":
			now = strftime("%H:%M")
			font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
			w,h = draw.textsize(now, font=font)
			lx = getSplit(ConfigSplit,ConfigAlign,MAX_W,w)
			draw.text((lx, pp), now, font=font, fill=ConfigColor)

# Bild
	def putBild(ConfigPos, ConfigSize, ConfigAlign, ConfigFile, im):
		MAX_W,MAX_H = im.size
		if os.path.isfile(ConfigFile):
			x = ConfigSize
			try:
				pil_image = Image.open(ConfigFile)
				xx,yy = pil_image.size
				y=int(float(x)/xx*yy)
				image_new = pil_image.resize((x, y), Image.ANTIALIAS) #BILINEAR)
				POSX = getSplit(False,ConfigAlign,MAX_W,x)
				im.paste(image_new,(POSX,ConfigPos))
			except:
				pass

# Grab
	def putGrab(ConfigFast,ConfigSize, im):
		global OSDon
		MAX_W,MAX_H = im.size
		CF = "" if ConfigFast == True else "-b"
#		os.system("/usr/bin/grab -o -p -b -r %d /tmp/dpfgrab.png >/dev/null 2>&1" % ConfigSize ) 
		os.system("/usr/bin/grab -o -p -j 95 %s -r %d /tmp/dpfgrab.jpg >/dev/null 2>&1" % (CF,ConfigSize) ) 
		if os.path.isfile("/tmp/dpfgrab.jpg"):
			pil_image = Image.open("/tmp/dpfgrab.jpg")
			xx,yy = pil_image.size
			if OSDon > 0:
				im.paste(pil_image,((MAX_W-xx)/2, (MAX_H-yy)/2))

# next Timer Record
	def putTimer(ConfigPos, ConfigSize, ConfigColor, draw, im):
		findTimer = False
		font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
		timercount = 0
		for timerlist in self.recordtimer.timer_list:
			if timerlist.disabled == 0 and timerlist.justplay == 0:
				timercount += 1
				if findTimer == False:
					findTimer = True
					begin = strftime("%d. %H:%M", localtime(int(timerlist.begin)+(config.recording.margin_before.value*60)))
					timer_name = timerlist.name.replace('\xc2\x86', '').replace('\xc2\x87', '').decode("utf-8", "ignore").encode("utf-8") or ""
					timer_name = codecs.decode(timer_name, 'UTF-8')
					w,h = draw.textsize(begin, font=font)
					draw.ellipse((2, ConfigPos+2, h-4, ConfigPos+h-4), fill="red") 
					draw.text((h+5, ConfigPos), begin, font=font, fill=ConfigColor)
					draw.text((h+5, ConfigPos+h), timer_name, font=font, fill=ConfigColor)
		if not findTimer:
			w,h = draw.textsize(_("no Timer"), font=font)
			draw.text((h+5, ConfigPos), _("no Timer"), font=font, fill=ConfigColor)
		else:
			font = ImageFont.truetype(FONT, h-6, encoding='unic')
			draw.text((int(h/4), ConfigPos+1), str(timercount), font=font, fill="white")

# Picon
	def putPicon(ConfigSize, ConfigType, ConfigAlign, ConfigTextSize, draw, im):
		sref = self.session.nav.getCurrentlyPlayingServiceReference()
		MAXi_W,MAXi_H = im.size
		if sref is not None:
			MAX_W,MAX_H = ConfigSize,int(MAXi_H/2)
			if ConfigType == "1":
				MAX_W,MAX_H = MAXi_W,MAXi_H
			ret=getpiconres(MAX_W, MAX_H, sref.toString())
			POSX, POSY = 0,0
			if ConfigType == "3":
				POSY = MAXi_H/2
			POSX = getSplit(False,ConfigAlign,MAXi_W,MAX_W)
			if ret == "":
				ref = eServiceReference(sref.toString())
				ref.setName("")
				serviceHandler = eServiceCenter.getInstance()
				info = serviceHandler.info(ref)
				channel_name = info and info.getName(ref).replace('\xc2\x86', '').replace('\xc2\x87', '').decode("utf-8", "ignore").encode("utf-8") or ""
				channel_name = codecs.decode(channel_name, 'UTF-8')

				font = ImageFont.truetype(FONT, ConfigTextSize, encoding='unic')
				Channel_list = textwrap.wrap(channel_name,width=int((MAX_W*2)/ConfigTextSize), break_long_words=False)
				hadd = 0
				for Channel_line in Channel_list:
					w,h = draw.textsize(Channel_line, font=font)
					TextSize = ConfigTextSize
					while w > MAX_W:
						TextSize -= 1
						font = ImageFont.truetype(FONT, TextSize, encoding='unic')
						w,h = draw.textsize(Channel_line, font=font)
					draw.text((((MAX_W-w)/2)+POSX,(POSY+hadd)), Channel_line, font=font, fill="white")
					hadd+=h
			else:
				try:
					pil_image = Image.open(ret)
					if ConfigType == "3":
						x,y=pil_image.size
						POSY = MAXi_H-y
					im.paste(pil_image,(POSX,POSY))
				except:
					pass

# aktive Sendernummer
	def putChannelNum(ConfigPos, ConfigSize, ConfigAlign, ConfigBackColor, ConfigColor, draw, im):
		MAX_W,MAX_H = im.size
		sref = self.session.nav.getCurrentlyPlayingServiceReference()
		if sref is not None:
			ref = eServiceReference(sref.toString())
			num = str(getNumber(ref))
			if num == "None":
				num = ""
		else:
			num = ""
#		print "Channel Number", num
		font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
		w,h = draw.textsize(num, font=font)
		lx = getSplit(False,ConfigAlign,MAX_W,w)
		if ConfigBackColor !="0":
			draw.rectangle((lx, ConfigPos, lx+w, ConfigPos+h),fill=ConfigBackColor)
		draw.text((lx, ConfigPos), num, font=font, fill=ConfigColor)

# aktive Sendername
	def putChannel(ConfigPos, ConfigSize, ConfigColor, draw, im):
		MAX_W,MAX_H = im.size
		sref = self.session.nav.getCurrentlyPlayingServiceReference()
		if sref is not None:
			ref = eServiceReference(sref.toString())
			ref.setName("")
			serviceHandler = eServiceCenter.getInstance()
			info = serviceHandler.info(ref)
			channel_name = info and info.getName(ref).replace('\xc2\x86', '').replace('\xc2\x87', '').decode("utf-8", "ignore").encode("utf-8") or ""
			ch = sref.toString().split("::")
			if len(ch) > 1:
				channel_name = ch[1].replace('\xc2\x86', '').replace('\xc2\x87', '').decode("utf-8", "ignore").encode("utf-8") or ""
			channel_name = codecs.decode(channel_name, 'UTF-8')
		else:
			channel_name = ""
		font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
		w,h = draw.textsize(channel_name, font=font)
		while w > MAX_W:
			ConfigSize -= 1
			font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
			w,h = draw.textsize(channel_name, font=font)
		draw.text(((MAX_W-w)/2, ConfigPos), channel_name, font=font, fill=ConfigColor)
				
# Progress Bar
	def putProgress(ConfigPos, ConfigSize, ConfigType, ConfigColor, ConfigAlign, draw, im):
		global isVideoPlaying
		MAX_W,MAX_H = im.size
		POSX = 0
		if ConfigAlign != "1":
			MAX_W = int(MAX_W/2)
			if ConfigAlign == "2":
				POSX=MAX_W 
		isVideoPlaying = 0
		ref = self.session.nav.getCurrentlyPlayingServiceReference()
		event_run=0
		ProgressBar = MAX_W-20
		if ref:
			path = ref.getPath()
			font = ImageFont.truetype(FONT, ConfigSize+5, encoding='unic')
			if path: # Movie
				isVideoPlaying = 1
				service = self.session.nav.getCurrentService()
				seek = service and service.seek()
				if seek:
					length = seek.getLength()
					position = seek.getPlayPosition()
					if length and position:
						if length[1] > 0:
							if ConfigType == "2":
								remaining = "%+d min" % int((length[1] - position[1])/90000/60)
								w,h = draw.textsize(remaining, font=font)
								ProgressBar -= (w+10)
								draw.text((ProgressBar+15+POSX, ConfigPos+1-(h-ConfigSize)/2),remaining, font=font, fill=ConfigColor)
							elif ConfigType == "3":
								remaining = "%d %%" % int(position[1]*100/length[1])
								w,h = draw.textsize(remaining, font=font)
								ProgressBar -= (w+10)
								draw.text((ProgressBar+15+POSX, ConfigPos+1-(h-ConfigSize)/2),remaining, font=font, fill=ConfigColor)
							event_run=int(ProgressBar*position[1]/length[1])
#						if remaining > 0:
#							remaining = remaining / 90000
			else: # DVB 
				event_begin, event_end, duration, event_name = getServiceInfo(self,0)
				if event_begin != 0:
					now = int(time())
					event_run = now - event_begin
					if ConfigType == "2":
						remaining = "%+d min" % int((event_end - now)/60)
						w,h = draw.textsize(remaining, font=font)
						ProgressBar -= (w+10)
						draw.text((ProgressBar+15+POSX, ConfigPos+1-(h-ConfigSize)/2),remaining, font=font, fill=ConfigColor)
					elif ConfigType == "3":
						remaining = "%d %%" % int(event_run*100/duration)
						w,h = draw.textsize(remaining, font=font)
						ProgressBar -= (w+10)
						draw.text((ProgressBar+15+POSX, ConfigPos+1-(h-ConfigSize)/2),remaining, font=font, fill=ConfigColor)
					event_run = int(ProgressBar*event_run/duration)
#					print event_begin, event_end, event.getDuration(), event.getPlayPosition()
			if event_run <0:
				event_run = 0
			if event_run > ProgressBar:
				event_run = ProgressBar
			draw.rectangle((POSX+9,ConfigPos,POSX+ProgressBar+11,ConfigPos+ConfigSize),outline=ConfigColor)
			draw.rectangle((POSX+10,ConfigPos,POSX+event_run+10,ConfigPos+ConfigSize),fill=ConfigColor)

# aktive Event
	def putProg(ConfigPos, ConfigSize, ConfigLines, ConfigType, ConfigColor, ConfigAlign, ConfigSplit, draw, im):
		MAX_W,MAX_H = im.size
		event_begin, event_end, duration, event_name = getServiceInfo(self,0)
		if event_begin != 0:
			font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
			begin = strftime("%H:%M", localtime(event_begin))
			ende = strftime("%H:%M", localtime(event_end))
			sts = ""
			if ConfigType == "1":
				sts = begin +" - " + ende + "\n"
			sts += event_name
			writeMultiline(sts,ConfigSize,ConfigPos,ConfigLines,ConfigColor,ConfigAlign,ConfigSplit,draw,im)

# next Event
	def putProgNext(ConfigPos, ConfigSize, ConfigLines, ConfigType, ConfigColor, ConfigAlign, ConfigSplit, draw, im):
		MAX_W,MAX_H = im.size
		event_begin, event_end, duration, event_name = getServiceInfo(self,1)
		if event_begin != 0:
			font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
			begin = strftime("%H:%M", localtime(event_begin))
			ende = strftime("%H:%M", localtime(event_end))
			sts = ""
			if ConfigType == "1":
				sts = begin +" - " + ende + "\n"
			sts += event_name
			writeMultiline(sts,ConfigSize,ConfigPos,ConfigLines,ConfigColor,ConfigAlign,ConfigSplit,draw,im)

# TunerInfo + Sensors
	def putInfo(ConfigPos, ConfigSize, ConfigAlign, ConfigSplit, ConfigColor, ConfigInfo, draw, im):
		MAX_W,MAX_H = im.size
		if ConfigSplit == True:
			MAX_W = int(MAX_W/2)
		i = ""
		service = self.session.nav.getCurrentService()
		if service is not None:
			feinfo = service.frontendInfo()
			if feinfo is not None:
				if ConfigInfo.find("A") >= 0:
					i += " %3.02fdB" % (feinfo.getFrontendInfo(iFrontendInformation.signalQualitydB) / 100.0)
				if ConfigInfo.find("B") >= 0:
					i += " %d%%" % (feinfo.getFrontendInfo(iFrontendInformation.signalQuality) * 100 / 65536)
				if ConfigInfo.find("C") >= 0:
					i += " %d" % (feinfo.getFrontendInfo(iFrontendInformation.bitErrorRate))
#			print "%d" % (feinfo.getFrontendInfo(iFrontendInformation.signalPower))
		if ConfigInfo.find("T") >= 0:
			m1 = 0
			if os.path.exists("/proc/stb/sensors"):
				for dirname in os.listdir("/proc/stb/sensors"):
					if dirname.find("temp", 0, 4) == 0:
						if os.path.isfile("/proc/stb/sensors/%s/value" % dirname) == True:
							f = open("/proc/stb/sensors/%s/value" % dirname, "r")
							tt = int(f.readline().strip())
							f.close()
							if m1 < tt:
								m1 = tt
			i += " %d\xb0C" % m1
		if ConfigInfo.find("R") >= 0:
			if os.path.isfile("/proc/stb/fp/fan_speed"):
				f = open("/proc/stb/fp/fan_speed", "r")
				value = int(f.readline().strip()[:-4])
				f.close()
				i += " %drpm" % int(value / 2)
		font = ImageFont.truetype(FONT, ConfigSize, encoding='unic')
		w,h = draw.textsize(i, font=font)
		lx = getSplit(ConfigSplit,ConfigAlign,MAX_W,w)
		draw.text((lx, ConfigPos), i, font=font, fill=ConfigColor)

# show Title
	def putTitle(ConfigPos, ConfigSize, ConfigLines, ConfigColor, ConfigAlign, ConfigSplit, draw, im):
		MAX_W,MAX_H = im.size
		service = self.session.nav.getCurrentService()
		Title = ""
		if service is not None:
			Title = service.info().getInfoString(iServiceInformation.sTagTitle)
			Video = Title.endswith(".mpg") or Title.endswith(".vob") or Title.endswith(".avi") or Title.endswith(".divx") or Title.endswith(".mv4") or Title.endswith(".mkv") or Title.endswith(".mp4") or Title.endswith(".ts")
			if Title == "" or Video == True:
				Title = service.info().getName()
				if Video == True:
					Title = Title.replace(".mpg","").replace(".vob","").replace(".avi","").replace(".divx","").replace(".mv4","").replace(".mkv","").replace(".mp4","").replace(".ts","")
			if Title.find(" ") > 20 or (Title.find(" ") == -1 and len(Title) > 20):
				Title = Title.replace("."," ")
			if ConfigMode == True:
				Title = "Title1\nTitle2 Text\nTitle3"
			writeMultiline(Title,ConfigSize,ConfigPos,ConfigLines,ConfigColor,ConfigAlign,ConfigSplit,draw,im)

# show Info1
	def putInfo1(ConfigPos, ConfigSize, ConfigLines, ConfigColor, ConfigAlign, ConfigSplit, draw, im):
		MAX_W,MAX_H = im.size
		service = self.session.nav.getCurrentService()
		Info = ""
		if service is not None:
			I = service.info().getInfoString(iServiceInformation.sTagArtist)
			if I is not None and I != "":
				Info += I + "\n"
			I = service.info().getInfoString(iServiceInformation.sTagGenre)
			if I is not None and I != "":
				Info += I + "\n"
			if isMediaPlayer == "radio":
				event_begin, event_end, duration, event_name = getServiceInfo(self,0)
				if event_begin != 0:
					Info += event_name + "\n"
				event_begin, event_end, duration, event_name = getServiceInfo(self,1)
				if event_begin != 0:
					Info += strftime("%H:%M ", localtime(event_begin)) + event_name
			if ConfigMode == True:
				Info = "Info1\nInfo2 Text\nInfo3"
			writeMultiline(Info,ConfigSize,ConfigPos,ConfigLines,ConfigColor,ConfigAlign,ConfigSplit,draw,im)

# show isRecording
	def putRecording(im):
		MAX_W,MAX_H = im.size
		if config.plugins.LCD4linux.Recording.value == True:
			if self.session.nav.RecordTimer.isRecording():
				draw.ellipse((MAX_W-25, -25, MAX_W+25, 25), fill="red") 

# Auszeit Hintergrundbeleuchtung 
	def isOffTime(b,e):
		t=localtime()
		tt = time()
		bT=mktime(datetime(t.tm_year,t.tm_mon,t.tm_mday,b[0],b[1]).timetuple()) 
		eT=mktime(datetime(t.tm_year,t.tm_mon,t.tm_mday,e[0],e[1]).timetuple())
		if eT < bT and tt > eT:
#			print "tt > eT +"
			eT += 86400
		if eT < bT and tt < eT:
#			print "tt < eT -"
			bT -= 86400
		return (bT < tt < eT)
		
###############
###############
###############
	if not config.plugins.LCD4linux.Enable.value:
		return
	tt = time()

	MAX_W,MAX_H = getResolution(config.plugins.LCD4linux.LCDType1.value)

	im = Image.new('RGB', (MAX_W, MAX_H), (0, 0, 0, 0))
	draw = ImageDraw.Draw(im)
	if config.plugins.LCD4linux.LCDType2.value != "00":
		MAX_W,MAX_H = getResolution(config.plugins.LCD4linux.LCDType2.value)
		im2 = Image.new('RGB', (MAX_W, MAX_H), (0, 0, 0, 0))
		draw2 = ImageDraw.Draw(im2)
####
#### Standby Modus
####
	if Standby.inStandby or ConfigStandby:
		if config.plugins.LCD4linux.Standby.value == "1":
			writeHelligkeit(config.plugins.LCD4linux.StandbyHelligkeit.value)
# LCDoff
			if config.plugins.LCD4linux.StandbyLCDoff.value <> config.plugins.LCD4linux.StandbyLCDon.value:
				if isOffTime(config.plugins.LCD4linux.StandbyLCDoff.value,config.plugins.LCD4linux.StandbyLCDon.value):
					writeHelligkeit(0)
					print "[LCD4linux] LCD off"
# Google Wetter
			if config.plugins.LCD4linux.StandbyWetter.value.find(ScreenActive) >= 0 and wwwWetter.find("forecast_information") > 1:
				if config.plugins.LCD4linux.StandbyWetterLCD.value.find("1") >= 0:
					putWetter(config.plugins.LCD4linux.StandbyWetterPos.value,config.plugins.LCD4linux.StandbyWetterType.value,draw,im)
				if config.plugins.LCD4linux.StandbyWetterLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putWetter(config.plugins.LCD4linux.StandbyWetterPos.value,config.plugins.LCD4linux.StandbyWetterType.value,draw2,im2)

# get clock
			if config.plugins.LCD4linux.StandbyClock.value.find(ScreenActive) >= 0:
				if config.plugins.LCD4linux.StandbyClockLCD.value.find("1") >= 0:
					putClock(config.plugins.LCD4linux.StandbyClockPos.value,config.plugins.LCD4linux.StandbyClockSize.value,config.plugins.LCD4linux.StandbyClockAlign.value,config.plugins.LCD4linux.StandbyClockSplit.value,config.plugins.LCD4linux.StandbyClockType.value,config.plugins.LCD4linux.StandbyClockColor.value, draw, im)
				if config.plugins.LCD4linux.StandbyClockLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putClock(config.plugins.LCD4linux.StandbyClockPos.value,config.plugins.LCD4linux.StandbyClockSize.value,config.plugins.LCD4linux.StandbyClockAlign.value,config.plugins.LCD4linux.StandbyClockSplit.value,config.plugins.LCD4linux.StandbyClockType.value,config.plugins.LCD4linux.StandbyClockColor.value, draw2, im2)
# next Timer Record
			if config.plugins.LCD4linux.StandbyTimer.value.find(ScreenActive) >= 0:
				if config.plugins.LCD4linux.StandbyTimerLCD.value.find("1") >= 0:
					putTimer(config.plugins.LCD4linux.StandbyTimerPos.value, config.plugins.LCD4linux.StandbyTimerSize.value, config.plugins.LCD4linux.StandbyTimerColor.value, draw, im)
				if config.plugins.LCD4linux.StandbyTimerLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putTimer(config.plugins.LCD4linux.StandbyTimerPos.value, config.plugins.LCD4linux.StandbyTimerSize.value, config.plugins.LCD4linux.StandbyTimerColor.value, draw2, im2)
# Bild
			if config.plugins.LCD4linux.StandbyBild.value.find(ScreenActive) >= 0:
				ShowPicture = ""
				if config.plugins.LCD4linux.StandbyBildFile.value.find("://") > 0:
					try:
						r = urllib.urlretrieve(config.plugins.LCD4linux.StandbyBildFile.value, HTTPpictmp)
#						print r[1]["content-type"]
						if r[1]["content-type"].find("image/") >=0:
							if os.path.isfile(HTTPpictmp):
								os.rename(HTTPpictmp,HTTPpic)
					except: 
						pass 
					finally:
						ShowPicture = HTTPpic
				else:
					if os.path.isdir(config.plugins.LCD4linux.StandbyBildFile.value):
						if len(BilderStandby) > 0:
							ShowPicture = BilderStandby[BilderIndexStandby]
							if BilderTime == 1: 
								BilderIndexStandby += 1
								if BilderIndexStandby >= len(BilderStandby):
									BilderIndexStandby = 0
					else:
						ShowPicture = config.plugins.LCD4linux.StandbyBildFile.value
				if config.plugins.LCD4linux.StandbyBildLCD.value.find("1") >= 0:
					putBild(config.plugins.LCD4linux.StandbyBildPos.value, config.plugins.LCD4linux.StandbyBildSize.value, config.plugins.LCD4linux.StandbyBildAlign.value, ShowPicture, im)
				if config.plugins.LCD4linux.StandbyBildLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putBild(config.plugins.LCD4linux.StandbyBildPos.value, config.plugins.LCD4linux.StandbyBildSize.value, config.plugins.LCD4linux.StandbyBildAlign.value, ShowPicture, im2)
# show Textfile
			if config.plugins.LCD4linux.StandbyText.value.find(ScreenActive) >= 0:
				if config.plugins.LCD4linux.StandbyTextLCD.value.find("1") >= 0:
					putTextFile(config.plugins.LCD4linux.StandbyTextPos.value,config.plugins.LCD4linux.StandbyTextSize.value,config.plugins.LCD4linux.StandbyTextAlign.value,config.plugins.LCD4linux.StandbyTextColor.value,config.plugins.LCD4linux.StandbyTextBackColor.value, config.plugins.LCD4linux.StandbyTextFile.value, draw, im)
				if config.plugins.LCD4linux.StandbyTextLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putTextFile(config.plugins.LCD4linux.StandbyTextPos.value,config.plugins.LCD4linux.StandbyTextSize.value,config.plugins.LCD4linux.StandbyTextAlign.value,config.plugins.LCD4linux.StandbyTextColor.value,config.plugins.LCD4linux.StandbyTextBackColor.value, config.plugins.LCD4linux.StandbyTextFile.value, draw2, im2)
# show Textfile 2
			if config.plugins.LCD4linux.StandbyText2.value.find(ScreenActive) >= 0:
				if config.plugins.LCD4linux.StandbyText2LCD.value.find("1") >= 0:
					putTextFile(config.plugins.LCD4linux.StandbyText2Pos.value,config.plugins.LCD4linux.StandbyText2Size.value,config.plugins.LCD4linux.StandbyText2Align.value,config.plugins.LCD4linux.StandbyText2Color.value,config.plugins.LCD4linux.StandbyText2BackColor.value, config.plugins.LCD4linux.StandbyText2File.value, draw, im)
				if config.plugins.LCD4linux.StandbyText2LCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putTextFile(config.plugins.LCD4linux.StandbyText2Pos.value,config.plugins.LCD4linux.StandbyText2Size.value,config.plugins.LCD4linux.StandbyText2Align.value,config.plugins.LCD4linux.StandbyText2Color.value,config.plugins.LCD4linux.StandbyText2BackColor.value, config.plugins.LCD4linux.StandbyText2File.value, draw2, im2)
# show HTTP Text
			if config.plugins.LCD4linux.StandbyHTTP.value.find(ScreenActive) >= 0:
				if config.plugins.LCD4linux.StandbyHTTPLCD.value.find("1") >= 0:
					putHTTP(config.plugins.LCD4linux.StandbyHTTPPos.value,config.plugins.LCD4linux.StandbyHTTPSize.value,config.plugins.LCD4linux.StandbyHTTPAlign.value,config.plugins.LCD4linux.StandbyHTTPColor.value,config.plugins.LCD4linux.StandbyHTTPBackColor.value, config.plugins.LCD4linux.StandbyHTTPURL.value, draw, im)
				if config.plugins.LCD4linux.StandbyHTTPLCD.value.find("2") >= 0:
					putHTTP(config.plugins.LCD4linux.StandbyHTTPPos.value,config.plugins.LCD4linux.StandbyHTTPSize.value,config.plugins.LCD4linux.StandbyHTTPAlign.value,config.plugins.LCD4linux.StandbyHTTPColor.value,config.plugins.LCD4linux.StandbyHTTPBackColor.value, config.plugins.LCD4linux.StandbyHTTPURL.value, draw2, im2)
# show isRecording
			putRecording(im)

		else:
			writeHelligkeit(0)
####
#### MediaPlayer
####
	elif isMediaPlayer != "":
		writeHelligkeit(config.plugins.LCD4linux.Helligkeit.value)
# Progress Bar
		if config.plugins.LCD4linux.MPProgress.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.MPProgressLCD.value.find("1") >= 0:
				putProgress(config.plugins.LCD4linux.MPProgressPos.value, config.plugins.LCD4linux.MPProgressSize.value, config.plugins.LCD4linux.MPProgressType.value, config.plugins.LCD4linux.MPProgressColor.value, config.plugins.LCD4linux.MPProgressAlign.value, draw, im)
			if config.plugins.LCD4linux.MPProgressLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putProgress(config.plugins.LCD4linux.MPProgressPos.value, config.plugins.LCD4linux.MPProgressSize.value, config.plugins.LCD4linux.MPProgressType.value, config.plugins.LCD4linux.MPProgressColor.value, config.plugins.LCD4linux.MPProgressAlign.value, draw2, im2)
# Title
		if config.plugins.LCD4linux.MPTitle.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.MPTitleLCD.value.find("1") >= 0:
				putTitle(config.plugins.LCD4linux.MPTitlePos.value, config.plugins.LCD4linux.MPTitleSize.value, config.plugins.LCD4linux.MPTitleLines.value, config.plugins.LCD4linux.MPTitleColor.value, config.plugins.LCD4linux.MPTitleAlign.value, config.plugins.LCD4linux.MPTitleSplit.value, draw, im)
			if config.plugins.LCD4linux.MPTitleLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putTitle(config.plugins.LCD4linux.MPTitlePos.value, config.plugins.LCD4linux.MPTitleSize.value, config.plugins.LCD4linux.MPTitleLines.value, config.plugins.LCD4linux.MPTitleColor.value, config.plugins.LCD4linux.MPTitleAlign.value, config.plugins.LCD4linux.MPTitleSplit.value, draw2, im2)
# Info1
		if config.plugins.LCD4linux.MPInfo1.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.MPInfo1LCD.value.find("1") >= 0:
				putInfo1(config.plugins.LCD4linux.MPInfo1Pos.value, config.plugins.LCD4linux.MPInfo1Size.value, config.plugins.LCD4linux.MPInfo1Lines.value, config.plugins.LCD4linux.MPInfo1Color.value, config.plugins.LCD4linux.MPInfo1Align.value, config.plugins.LCD4linux.MPInfo1Split.value, draw, im)
			if config.plugins.LCD4linux.MPInfo1LCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putInfo1(config.plugins.LCD4linux.MPInfo1Pos.value, config.plugins.LCD4linux.MPInfo1Size.value, config.plugins.LCD4linux.MPInfo1Lines.value, config.plugins.LCD4linux.MPInfo1Color.value, config.plugins.LCD4linux.MPInfo1Align.value, config.plugins.LCD4linux.MPInfo1Split.value, draw2, im2)
# show OSD
		if config.plugins.LCD4linux.OSD.value != "0" and ConfigMode == False:
			if OSDon >= 2:
				if config.plugins.LCD4linux.OSDLCD.value.find("1") >= 0:
					putGrab(config.plugins.LCD4linux.OSDfast.value, config.plugins.LCD4linux.OSDsize.value,im)
				if config.plugins.LCD4linux.OSDLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putGrab(config.plugins.LCD4linux.OSDfast.value, config.plugins.LCD4linux.OSDsize.value,im2)
				if OSDon == 3:
					OSDon = 2
# get clock
		if config.plugins.LCD4linux.MPClock.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.MPClockLCD.value.find("1") >= 0:
				putClock(config.plugins.LCD4linux.MPClockPos.value,config.plugins.LCD4linux.MPClockSize.value,config.plugins.LCD4linux.MPClockAlign.value,config.plugins.LCD4linux.MPClockSplit.value,config.plugins.LCD4linux.MPClockType.value,config.plugins.LCD4linux.MPClockColor.value, draw, im)
			if config.plugins.LCD4linux.MPClockLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putClock(config.plugins.LCD4linux.MPClockPos.value,config.plugins.LCD4linux.MPClockSize.value,config.plugins.LCD4linux.MPClockAlign.value,config.plugins.LCD4linux.MPClockSplit.value,config.plugins.LCD4linux.MPClockType.value,config.plugins.LCD4linux.MPClockColor.value, draw2, im2)
	else:
####
#### ON Modus
####
		writeHelligkeit(config.plugins.LCD4linux.Helligkeit.value)
# LCDoff
		if config.plugins.LCD4linux.LCDoff.value <> config.plugins.LCD4linux.LCDon.value or LCDon == False:
			if isOffTime(config.plugins.LCD4linux.LCDoff.value,config.plugins.LCD4linux.LCDon.value) or LCDon == False:
				writeHelligkeit(0)
				print "[LCD4linux] LCD off"
# Picon
		if config.plugins.LCD4linux.Picon.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.PiconLCD.value.find("1") >= 0:
				putPicon(config.plugins.LCD4linux.PiconSize.value, config.plugins.LCD4linux.PiconType.value, config.plugins.LCD4linux.PiconAlign.value, config.plugins.LCD4linux.PiconTextSize.value, draw, im)
			if config.plugins.LCD4linux.PiconLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putPicon(config.plugins.LCD4linux.PiconSize.value, config.plugins.LCD4linux.PiconType.value, config.plugins.LCD4linux.PiconAlign.value, config.plugins.LCD4linux.PiconTextSize.value, draw2, im2)
# Google Wetter
		if config.plugins.LCD4linux.Wetter.value.find(ScreenActive) >= 0 and wwwWetter.find("forecast_information") > 1:
			if config.plugins.LCD4linux.WetterLCD.value.find("1") >= 0:
				putWetter(config.plugins.LCD4linux.WetterPos.value,config.plugins.LCD4linux.WetterType.value,draw,im)
			if config.plugins.LCD4linux.WetterLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putWetter(config.plugins.LCD4linux.WetterPos.value,config.plugins.LCD4linux.WetterType.value,draw2,im2)
# get clock
		if config.plugins.LCD4linux.Clock.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.ClockLCD.value.find("1") >= 0:
				putClock(config.plugins.LCD4linux.ClockPos.value,config.plugins.LCD4linux.ClockSize.value,config.plugins.LCD4linux.ClockAlign.value,config.plugins.LCD4linux.ClockSplit.value,config.plugins.LCD4linux.ClockType.value,config.plugins.LCD4linux.ClockColor.value, draw, im)
			if config.plugins.LCD4linux.ClockLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putClock(config.plugins.LCD4linux.ClockPos.value,config.plugins.LCD4linux.ClockSize.value,config.plugins.LCD4linux.ClockAlign.value,config.plugins.LCD4linux.ClockSplit.value,config.plugins.LCD4linux.ClockType.value,config.plugins.LCD4linux.ClockColor.value, draw2, im2)
# Informationen
		if config.plugins.LCD4linux.Info.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.InfoLCD.value.find("1") >= 0:
				putInfo(config.plugins.LCD4linux.InfoPos.value, config.plugins.LCD4linux.InfoSize.value,config.plugins.LCD4linux.InfoAlign.value,config.plugins.LCD4linux.InfoSplit.value,config.plugins.LCD4linux.InfoColor.value,config.plugins.LCD4linux.InfoTuner.value+config.plugins.LCD4linux.InfoSensor.value, draw, im)
			if config.plugins.LCD4linux.InfoLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putInfo(config.plugins.LCD4linux.InfoPos.value, config.plugins.LCD4linux.InfoSize.value,config.plugins.LCD4linux.InfoAlign.value,config.plugins.LCD4linux.InfoSplit.value,config.plugins.LCD4linux.InfoColor.value,config.plugins.LCD4linux.InfoTuner.value+config.plugins.LCD4linux.InfoSensor.value, draw2, im2)
# next Timer Record
			if config.plugins.LCD4linux.Timer.value.find(ScreenActive) >= 0:
				if config.plugins.LCD4linux.TimerLCD.value.find("1") >= 0:
					putTimer(config.plugins.LCD4linux.TimerPos.value, config.plugins.LCD4linux.TimerSize.value, config.plugins.LCD4linux.TimerColor.value, draw, im)
				if config.plugins.LCD4linux.TimerLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putTimer(config.plugins.LCD4linux.TimerPos.value, config.plugins.LCD4linux.TimerSize.value, config.plugins.LCD4linux.TimerColor.value, draw2, im2)
# aktive Sendernummer
		if config.plugins.LCD4linux.ChannelNum.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.ChannelNumLCD.value.find("1") >= 0:
				putChannelNum(config.plugins.LCD4linux.ChannelNumPos.value, config.plugins.LCD4linux.ChannelNumSize.value, config.plugins.LCD4linux.ChannelNumAlign.value, config.plugins.LCD4linux.ChannelNumBackColor.value, config.plugins.LCD4linux.ChannelNumColor.value, draw, im)
			if config.plugins.LCD4linux.ChannelNumLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putChannelNum(config.plugins.LCD4linux.ChannelNumPos.value, config.plugins.LCD4linux.ChannelNumSize.value, config.plugins.LCD4linux.ChannelNumAlign.value, config.plugins.LCD4linux.ChannelNumBackColor.value, config.plugins.LCD4linux.ChannelNumColor.value, draw2, im2)
# aktive Sendername
		if config.plugins.LCD4linux.Channel.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.ChannelLCD.value.find("1") >= 0:
				putChannel(config.plugins.LCD4linux.ChannelPos.value, config.plugins.LCD4linux.ChannelSize.value, config.plugins.LCD4linux.ChannelColor.value, draw, im)
			if config.plugins.LCD4linux.ChannelLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putChannel(config.plugins.LCD4linux.ChannelPos.value, config.plugins.LCD4linux.ChannelSize.value, config.plugins.LCD4linux.ChannelColor.value, draw2, im2)
# Progress Bar
		if config.plugins.LCD4linux.Progress.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.ProgressLCD.value.find("1") >= 0:
				putProgress(config.plugins.LCD4linux.ProgressPos.value, config.plugins.LCD4linux.ProgressSize.value, config.plugins.LCD4linux.ProgressType.value, config.plugins.LCD4linux.ProgressColor.value, config.plugins.LCD4linux.ProgressAlign.value, draw, im)
			if config.plugins.LCD4linux.ProgressLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putProgress(config.plugins.LCD4linux.ProgressPos.value, config.plugins.LCD4linux.ProgressSize.value, config.plugins.LCD4linux.ProgressType.value, config.plugins.LCD4linux.ProgressColor.value, config.plugins.LCD4linux.ProgressAlign.value, draw2, im2)
# aktive Event
		if config.plugins.LCD4linux.Prog.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.ProgLCD.value.find("1") >= 0:
				putProg(config.plugins.LCD4linux.ProgPos.value, config.plugins.LCD4linux.ProgSize.value, config.plugins.LCD4linux.ProgLines.value, config.plugins.LCD4linux.ProgType.value, config.plugins.LCD4linux.ProgColor.value, config.plugins.LCD4linux.ProgAlign.value, config.plugins.LCD4linux.ProgSplit.value, draw, im)
			if config.plugins.LCD4linux.ProgLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putProg(config.plugins.LCD4linux.ProgPos.value, config.plugins.LCD4linux.ProgSize.value, config.plugins.LCD4linux.ProgLines.value, config.plugins.LCD4linux.ProgType.value, config.plugins.LCD4linux.ProgColor.value, config.plugins.LCD4linux.ProgAlign.value, config.plugins.LCD4linux.ProgSplit.value, draw2, im2)
# next Event
		if config.plugins.LCD4linux.ProgNext.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.ProgNextLCD.value.find("1") >= 0:
				putProgNext(config.plugins.LCD4linux.ProgNextPos.value, config.plugins.LCD4linux.ProgNextSize.value, config.plugins.LCD4linux.ProgNextLines.value, config.plugins.LCD4linux.ProgNextType.value, config.plugins.LCD4linux.ProgNextColor.value, config.plugins.LCD4linux.ProgNextAlign.value, config.plugins.LCD4linux.ProgNextSplit.value, draw, im)
			if config.plugins.LCD4linux.ProgNextLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putProgNext(config.plugins.LCD4linux.ProgNextPos.value, config.plugins.LCD4linux.ProgNextSize.value, config.plugins.LCD4linux.ProgNextLines.value, config.plugins.LCD4linux.ProgNextType.value, config.plugins.LCD4linux.ProgNextColor.value, config.plugins.LCD4linux.ProgNextAlign.value, config.plugins.LCD4linux.ProgNextSplit.value, draw2, im2)
# Bild
		if config.plugins.LCD4linux.Bild.value.find(ScreenActive) >= 0:
			ShowPicture = ""
			if config.plugins.LCD4linux.BildFile.value.find("://") > 0:
				try:
					r = urllib.urlretrieve(config.plugins.LCD4linux.BildFile.value, HTTPpictmp)
#					print r[1]["content-type"]
					if r[1]["content-type"].find("image/") >=0:
						if os.path.isfile(HTTPpictmp):
							os.rename(HTTPpictmp,HTTPpic)
				except: 
					pass 
				finally:
					ShowPicture = HTTPpic
			else:
				if os.path.isdir(config.plugins.LCD4linux.BildFile.value):
					if len(Bilder) > 0:
						ShowPicture = Bilder[BilderIndex]
						if BilderTime == 1: 
							BilderIndex += 1
							if BilderIndex >= len(Bilder):
								BilderIndex = 0
				else:
					ShowPicture = config.plugins.LCD4linux.BildFile.value
					if ShowPicture.find("fritz") >= 0:
						OSDon = 1
			if config.plugins.LCD4linux.BildLCD.value.find("1") >= 0:
				putBild(config.plugins.LCD4linux.BildPos.value, config.plugins.LCD4linux.BildSize.value, config.plugins.LCD4linux.BildAlign.value, ShowPicture, im)
			if config.plugins.LCD4linux.BildLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putBild(config.plugins.LCD4linux.BildPos.value, config.plugins.LCD4linux.BildSize.value, config.plugins.LCD4linux.BildAlign.value, ShowPicture, im2)
# show Textfile
		if config.plugins.LCD4linux.Text.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.TextLCD.value.find("1") >= 0:
				putTextFile(config.plugins.LCD4linux.TextPos.value,config.plugins.LCD4linux.TextSize.value,config.plugins.LCD4linux.TextAlign.value,config.plugins.LCD4linux.TextColor.value,config.plugins.LCD4linux.TextBackColor.value, config.plugins.LCD4linux.TextFile.value, draw, im)
			if config.plugins.LCD4linux.TextLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putTextFile(config.plugins.LCD4linux.TextPos.value,config.plugins.LCD4linux.TextSize.value,config.plugins.LCD4linux.TextAlign.value,config.plugins.LCD4linux.TextColor.value,config.plugins.LCD4linux.TextBackColor.value, config.plugins.LCD4linux.TextFile.value, draw2, im2)
# show Textfile 2
		if config.plugins.LCD4linux.Text2.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.Text2LCD.value.find("1") >= 0:
				putTextFile(config.plugins.LCD4linux.Text2Pos.value,config.plugins.LCD4linux.Text2Size.value,config.plugins.LCD4linux.Text2Align.value,config.plugins.LCD4linux.Text2Color.value,config.plugins.LCD4linux.Text2BackColor.value, config.plugins.LCD4linux.Text2File.value, draw, im)
			if config.plugins.LCD4linux.Text2LCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
				putTextFile(config.plugins.LCD4linux.Text2Pos.value,config.plugins.LCD4linux.Text2Size.value,config.plugins.LCD4linux.Text2Align.value,config.plugins.LCD4linux.Text2Color.value,config.plugins.LCD4linux.Text2BackColor.value, config.plugins.LCD4linux.Text2File.value, draw2, im2)
# show HTTP Text
		if config.plugins.LCD4linux.HTTP.value.find(ScreenActive) >= 0:
			if config.plugins.LCD4linux.HTTPLCD.value.find("1") >= 0:
				putHTTP(config.plugins.LCD4linux.HTTPPos.value,config.plugins.LCD4linux.HTTPSize.value,config.plugins.LCD4linux.HTTPAlign.value,config.plugins.LCD4linux.HTTPColor.value,config.plugins.LCD4linux.HTTPBackColor.value, config.plugins.LCD4linux.HTTPURL.value, draw, im)
			if config.plugins.LCD4linux.HTTPLCD.value.find("2") >= 0:
				putHTTP(config.plugins.LCD4linux.HTTPPos.value,config.plugins.LCD4linux.HTTPSize.value,config.plugins.LCD4linux.HTTPAlign.value,config.plugins.LCD4linux.HTTPColor.value,config.plugins.LCD4linux.HTTPBackColor.value, config.plugins.LCD4linux.HTTPURL.value, draw2, im2)
# show OSD
		if config.plugins.LCD4linux.OSD.value != "0" and ConfigMode == False:
			if OSDon >= 2:
				if config.plugins.LCD4linux.OSDLCD.value.find("1") >= 0:
					putGrab(config.plugins.LCD4linux.OSDfast.value, config.plugins.LCD4linux.OSDsize.value,im)
				if config.plugins.LCD4linux.OSDLCD.value.find("2") >= 0 and config.plugins.LCD4linux.LCDType2.value != "00":
					putGrab(config.plugins.LCD4linux.OSDfast.value, config.plugins.LCD4linux.OSDsize.value,im2)
				if OSDon == 3:
					OSDon = 2
# show isRecording
		putRecording(im)
# Ende
	if config.plugins.LCD4linux.LCDRotate1.value != "0":
		im=im.rotate(int(config.plugins.LCD4linux.LCDRotate1.value))
	if config.plugins.LCD4linux.LCDType1.value[0] == "1":
		im.save(PICtmp+".png", "PNG")
		if os.path.isfile(PICtmp+".png"):
			os.rename(PICtmp+".png",PIC+".png")
	if self.pngutilconnect == 0:
		print "[LCD4linux] RunTime:", time() - tt
		return
	pngutiltime = time()
	pngutil.send(PIC+".png")
	print "time(write to lcd) : ",time()-pngutiltime

	print "[LCD4linux] RunTime:", time() - tt
	 
	return
	
def main(session,**kwargs):
	session.open(LCDdisplayConfig)

def autostart(reason, **kwargs):
	global session
	if "session" in kwargs:
		session = kwargs["session"]
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/webif.py"):
			from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
			from twisted.web import static
			from WebSite import LCD4linuxweb
			root = static.File("/tmp")
			root.putChild("", LCD4linuxweb())
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web/external.xml"):
				addExternalChild( ("lcd4linux", root, "LCD4linux", Version) )
			else:
				addExternalChild( ("lcd4linux", root) )
		if os.path.isfile("/usr/lib/libpython2.5.so.1.0") == False:
			print "[LCD4linux] create Link"
#			os.system("ln -s libpython2.6.so.1.0 /usr/lib/libpython2.5.so.1.0")
		UpdateStatus(session)

def Plugins(**kwargs):
	list = [
	PluginDescriptor(name="LCD4linux", 
	description="LCD4linux", 
	where = [PluginDescriptor.WHERE_SESSIONSTART, 
	PluginDescriptor.WHERE_AUTOSTART], 
	fnc = autostart)]
	list.append(PluginDescriptor(name="LCD4linux", 
	description="LCD4linux", 
	where = PluginDescriptor.WHERE_PLUGINMENU,
	icon = "plugin.png",
	fnc = main))
	return list
